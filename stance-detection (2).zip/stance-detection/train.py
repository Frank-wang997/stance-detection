# -*- coding: utf-8 -*-
# file: train.py
# author: songyouwei <youwei0314@gmail.com>
# Copyright (C) 2018. All Rights Reserved.
import logging
import argparse
import math
import os
import sys
from time import strftime, localtime
import random
import numpy
from pandas import DataFrame
from pathlib import Path
from transformers import BertModel, XLNetForSequenceClassification, XLNetTokenizer

from sklearn import metrics
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, random_split

from bucket_iterator import BucketIterator, BertBucketIterator
from data_utils import build_tokenizer, build_embedding_matrix, Tokenizer4Bert, ABSADataset, LSTMDataset, DatesetReader

from models import LSTM, IAN, MemNet, RAM, TD_LSTM, TC_LSTM, Cabasc, ATAE_LSTM, TNet_LF, AOA, MGAN, LCF_BERT
from models.aen import CrossEntropyLoss_LSR, AEN_BERT
from models.bert_spc import BERT_SPC
from models.bert_lstm import BERT_LSTM
from models.bert_dynamic_lstm import BERT_DYNAMIC_LSTM
from models.lstm_gcn import LSTM_GCN
from models.xlnet_spc import XLNET_SPC
from models.bert_gcn import BERT_GCN
from models.TAN import TAN
from models.HAN import HAN

modelPath = os.path.dirname(os.path.realpath(__file__))
logger = logging.getLogger()
logger.setLevel(logging.INFO)
logger.addHandler(logging.StreamHandler(sys.stdout))
os.environ["CUDA_VISIBLE_DEVICES"] = "2"


class Instructor:
    def __init__(self, opt):
        self.opt = opt

        if 'bert' in opt.model_name:
            tokenizer = Tokenizer4Bert(opt.max_seq_len, opt.pretrained_bert_name)
            bert = BertModel.from_pretrained(opt.pretrained_bert_name)
            self.model = opt.model_class(bert, opt).to(opt.device)

            self.trainset = ABSADataset(opt.dataset_file['train'], tokenizer)
            # self.valset = ABSADataset(opt.dataset_file['dev'], tokenizer)
            self.testset = ABSADataset(opt.dataset_file['test'], tokenizer)

            self.train_data_loader = BertBucketIterator(data=self.trainset, batch_size=self.opt.batch_size, shuffle=True, sort_key='text_bert_indices')
            self.test_data_loader = BertBucketIterator(data=self.testset, batch_size=self.opt.batch_size, shuffle=False, sort_key='text_bert_indices')
        # elif 'xlnet' in opt.model_name:
        #     tokenizer = XLNetTokenizer.from_pretrained(opt.pretrained_xlnet_name)
        #     xlnet = XLNetForSequenceClassification.from_pretrained(opt.pretrained_xlnet_name, return_dict=True)
        #     self.model = opt.model_class(xlnet, opt).to(opt.device)
        else:
            stance_dataset = DatesetReader(dataset=opt.dataset, embed_dim=opt.embed_dim, w2v_name=opt.embed_name)
            self.model = opt.model_class(stance_dataset.embedding_matrix, opt).to(opt.device)
            self.train_data_loader = BucketIterator(data=stance_dataset.train_data, batch_size=opt.batch_size,
                                                    shuffle=True)
            self.test_data_loader = BucketIterator(data=stance_dataset.test_data, batch_size=opt.batch_size,
                                                   shuffle=False)

        if opt.device.type == 'cuda':
            logger.info('cuda memory allocated: {}'.format(torch.cuda.memory_allocated(device=opt.device.index)))
        self._print_args()

    def _print_args(self):
        n_trainable_params, n_nontrainable_params = 0, 0
        for p in self.model.parameters():
            n_params = torch.prod(torch.tensor(p.shape))
            if p.requires_grad:
                n_trainable_params += n_params
            else:
                n_nontrainable_params += n_params
        logger.info(
            'n_trainable_params: {0}, n_nontrainable_params: {1}'.format(n_trainable_params, n_nontrainable_params))
        logger.info('> training arguments:')
        for arg in vars(self.opt):
            logger.info('>>> {0}: {1}'.format(arg, getattr(self.opt, arg)))

    def _reset_params(self):
        for child in self.model.children():
            if type(child) != BertModel:  # skip bert params
                for p in child.parameters():
                    if p.requires_grad:
                        if len(p.shape) > 1:
                            self.opt.initializer(p)
                        else:
                            stdv = 1. / math.sqrt(p.shape[0])
                            torch.nn.init.uniform_(p, a=-stdv, b=stdv)

    def _train(self, criterion, optimizer, train_data_loader, val_data_loader):
        max_val_acc = 0
        max_val_f1 = 0
        global_step = 0
        path = None
        for epoch in range(self.opt.num_epoch):
            logger.info('>' * 100)
            logger.info('epoch: {}'.format(epoch))
            n_correct, n_total, loss_total = 0, 0, 0
            # switch model to training mode
            self.model.train()
            for i_batch, sample_batched in enumerate(train_data_loader):
                global_step += 1
                # clear gradient accumulators
                optimizer.zero_grad()

                inputs = [sample_batched[col].to(self.opt.device) for col in self.opt.inputs_cols]
                outputs = self.model(inputs)  # torch.Size([64, 3])
                targets = sample_batched['stance'].to(self.opt.device)  # torch.Size([64])
                # print("outputs输出维度:{}".format(outputs.shape))
                # print("targets输出维度:{}".format(targets))

                loss = criterion(outputs, targets)
                loss.backward()
                optimizer.step()

                n_correct += (torch.argmax(outputs, -1) == targets).sum().item()
                n_total += len(outputs)
                loss_total += loss.item() * len(outputs)
                if global_step % self.opt.log_step == 0:
                    train_acc = n_correct / n_total
                    train_loss = loss_total / n_total
                    logger.info('loss: {:.4f}, acc: {:.4f}'.format(train_loss, train_acc))

            val_acc, val_f1, _, _, _ = self._evaluate_acc_f1(val_data_loader)
            # logger.info('> val_acc: {:.4f}, val_f1: {:.4f}'.format(val_acc, val_f1))
            if val_f1 > max_val_f1:
                dirPath = modelPath + '/output'
                if not os.path.exists(dirPath):
                    os.mkdir(dirPath)
                # 删除准确率低的模型
                oldPath = dirPath + '/{0}_{1}_val_f1_{2}'.format(self.opt.model_name, self.opt.dataset,
                                                                 round(max_val_f1, 4))
                if os.path.exists(oldPath):
                    os.remove(oldPath)
                    logger.info('>> delete: {}'.format(oldPath))
                max_val_f1 = val_f1
                # 保存F1最好的模型
                path = dirPath + '/{0}_{1}_val_f1_{2}'.format(self.opt.model_name, self.opt.dataset,
                                                              round(max_val_f1, 4))
                torch.save(self.model.state_dict(), path)
                logger.info('>> saved: {}'.format(path))

            if val_f1 > max_val_f1:
                max_val_f1 = val_f1

        return path

    def _evaluate_acc_f1(self, data_loader):
        n_correct, n_total = 0, 0
        t_targets_all, t_outputs_all = None, None
        # switch model to evaluation mode
        self.model.eval()
        with torch.no_grad():
            for t_batch, t_sample_batched in enumerate(data_loader):
                t_inputs = [t_sample_batched[col].to(self.opt.device) for col in self.opt.inputs_cols]
                t_targets = t_sample_batched['stance'].to(self.opt.device)
                t_outputs = self.model(t_inputs)

                n_correct += (torch.argmax(t_outputs, -1) == t_targets).sum().item()
                n_total += len(t_outputs)

                if t_targets_all is None:
                    t_score = t_outputs
                    t_targets_all = t_targets
                    t_outputs_all = t_outputs
                else:
                    t_score = torch.cat((t_score, t_outputs), dim=0)
                    t_targets_all = torch.cat((t_targets_all, t_targets), dim=0)
                    t_outputs_all = torch.cat((t_outputs_all, t_outputs), dim=0)

        acc = n_correct / n_total
        y_true = t_targets_all.cpu()
        y_pred = torch.argmax(t_outputs_all, -1).cpu()
        f1_mac = metrics.f1_score(y_true, y_pred, labels=[0, 1, 2], average='macro')
        acc_sk = metrics.accuracy_score(y_true, y_pred)
        precision = metrics.precision_score(y_true, y_pred, labels=[0, 1, 2], average='macro')
        recall = metrics.recall_score(y_true, y_pred, labels=[0, 1, 2], average='macro')
        # test_score_convert = [x[1] for x in t_score]
        # 将一维标签转为二维
        y_array = y_true.tolist()
        for i in range(len(y_array)):
            if y_array[i] == 0:
                y_array[i] = [1, 0, 0]
            elif y_array[i] == 1:
                y_array[i] = [0, 1, 0]
            elif y_array[i] == 2:
                y_array[i] = [0, 0, 1]

        test_aucroc = metrics.roc_auc_score(numpy.array(y_array), t_score.cpu().numpy(), average='macro')

        logger.info("y_array={}".format(y_array))
        logger.info("test_true={}".format(y_true.tolist()))
        logger.info("test_score_convert={}".format(t_score.cpu().tolist()))

        class_result = metrics.classification_report(y_true, y_pred, target_names=['反对', '中立', '支持'], digits=4)
        print(class_result)
        # print(class_result)
        logger.info('>> test_acc: {:.4f}, test_precision:{:.4f}, test_recall:{:.4f}, test_f1: {:.4f}'.format(acc_sk, precision, recall, f1_mac))
        return acc_sk, f1_mac, y_array, y_true.tolist(), t_score.cpu().tolist()



    def recall_each_class(self, n_true, n_pred):
        favor, none, against = 0, 0, 0
        n_against = n_true.count(0)
        n_none = n_true.count(1)
        n_favor = n_true.count(2)
        for i in range(len(n_true)):
            if n_pred[i] == n_true[i]:
                if n_pred[i] == 0:
                    against += 1
                elif n_pred[i] == 1:
                    none += 1
                elif n_pred[i] == 2:
                    favor += 1
        try:
            x = favor / n_favor
        except ZeroDivisionError:
            x = 0
        try:
            y = against / n_against
        except ZeroDivisionError:
            y = 0
        try:
            z = none / n_none
        except ZeroDivisionError:
            z = 0
        print(">FAVOR:{:.4f}, AGAINST:{:.4f}, NONE:{:.4f}".format(x, y, z))

    def run(self):
        # Loss and Optimizer
        criterion = nn.CrossEntropyLoss()
        _params = filter(lambda p: p.requires_grad, self.model.parameters())
        optimizer = self.opt.optimizer(_params, lr=self.opt.learning_rate, weight_decay=self.opt.l2reg)
        # scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=5, gamma=0.5)



        self._reset_params()
        best_model_path = self._train(criterion, optimizer, self.train_data_loader, self.test_data_loader)
        self.model.load_state_dict(torch.load(best_model_path))
        self.model.eval()
        _, _, y_array, test_true, test_score_convert = self._evaluate_acc_f1(self.test_data_loader)
        logger.info("y_array={}".format(y_array))
        logger.info("test_true={}".format(test_true))
        logger.info("test_score_convert={}".format(test_score_convert))



def main():
    # Hyper Parameters
    parser = argparse.ArgumentParser()
    parser.add_argument('--model_name', default='tan', type=str)
    parser.add_argument('--dataset', default='SC', type=str, help='weibo, twitter, restaurant, laptop')
    parser.add_argument('--optimizer', default='adam', type=str)
    parser.add_argument('--initializer', default='xavier_uniform_', type=str)
    parser.add_argument('--learning_rate', default=5e-5, type=float, help='try 5e-5, 2e-5 for BERT, 1e-3 for others')
    parser.add_argument('--dropout', default=0.5, type=float)
    parser.add_argument('--l2reg', default=0.01, type=float)
    parser.add_argument('--num_epoch', default=50, type=int, help='try larger number for non-BERT models')
    parser.add_argument('--batch_size', default=64, type=int, help='try 16, 32, 64 for BERT models')
    parser.add_argument('--log_step', default=5, type=int)
    parser.add_argument('--embed_dim', default=300, type=int)
    parser.add_argument('--hidden_dim', default=300, type=int)
    parser.add_argument('--bert_dim', default=768, type=int)
    parser.add_argument('--pretrained_bert_name', default=modelPath + '/word-embedding/pretrain/bert_zh', type=str)
    parser.add_argument('--pretrained_xlnet_name', default=modelPath + '/word-embedding/pretrain/xlnet', type=str)
    parser.add_argument('--embed_name', default='glove-chinese-weibo', type=str)
    parser.add_argument('--max_seq_len', default=128, type=int)
    parser.add_argument('--polarities_dim', default=3, type=int)
    parser.add_argument('--hops', default=3, type=int)
    parser.add_argument('--device', default=2, type=str, help='e.g. cuda:0')
    parser.add_argument('--seed', default=1, type=int, help='set seed for reproducibility')
    parser.add_argument('--valset_ratio', default=0, type=float,
                        help='set ratio between 0 and 1 for validation support')
    parser.add_argument('--losstype', default=None, type=str,
                        help="['doubleloss', 'orthogonalloss', 'differentiatedloss']")
    parser.add_argument('--attention_heads', default=1, type=int, help='number of multi-attention heads')
    parser.add_argument('--gcn_dropout', type=float, default=0.1, help='GCN layer dropout rate.')

    # The following parameters are only valid for the lcf-bert model
    parser.add_argument('--local_context_focus', default='cdm', type=str, help='local context focus mode, cdw or cdm')
    parser.add_argument('--SRD', default=3, type=int,
                        help='semantic-relative-distance, see the paper of LCF-BERT model')
    opt = parser.parse_args()

    model_classes = {
        'lstm': LSTM,
        'td_lstm': TD_LSTM,
        'tc_lstm': TC_LSTM,
        'atae_lstm': ATAE_LSTM,
        'ian': IAN,
        'memnet': MemNet,
        'ram': RAM,
        'cabasc': Cabasc,
        'tnet_lf': TNet_LF,
        'aoa': AOA,
        'mgan': MGAN,
        'bert_spc': BERT_SPC,
        'aen_bert': AEN_BERT,
        'lcf_bert': LCF_BERT,
        'bert_lstm': BERT_LSTM,
        'bert_dynamic_lstm': BERT_DYNAMIC_LSTM,
        'xlnet_spc': XLNET_SPC,
        'bert_gcn': BERT_GCN,
        'lstm_gcn': LSTM_GCN,
        'tan': TAN,
        'han': HAN,

        # default hyper-parameters for LCF-BERT model is as follws:
        # lr: 2e-5
        # l2: 1e-5
        # batch size: 16
        # num epochs: 5
    }

    dataset_files = {
        'weibo': {
            'train': './datasets/weibo-train.raw',
            'test': './datasets/weibo-test.raw'
        },
        'SC': {
            'train': './datasets/SC-train.raw',
            'test': './datasets/SC-test.raw'
        },
        # 'twitter': {
        #     'train': './datasets/acl-14-short-data/train.raw',
        #     'test': './datasets/acl-14-short-data/test.raw'
        # },
    }
    input_colses = {
        'lstm': ['text_raw_indices'],
        # 'td_lstm': ['text_left_with_aspect_indices', 'text_right_with_aspect_indices'],
        # 'tc_lstm': ['text_left_with_aspect_indices', 'text_right_with_aspect_indices', 'aspect_indices'],
        'atae_lstm': ['text_raw_indices', 'target_indices'],
        'ian': ['text_raw_indices', 'target_indices'],
        'memnet': ['text_raw_without_target_indices', 'target_indices'],
        # 'ram': ['text_raw_indices', 'aspect_indices', 'text_left_indices'],
        # 'cabasc': ['text_raw_indices', 'aspect_indices', 'text_left_with_aspect_indices', 'text_right_with_aspect_indices'],
        # 'tnet_lf': ['text_raw_indices', 'aspect_indices', 'aspect_in_text'],
        'aoa': ['text_raw_indices', 'target_indices'],
        # 'mgan': ['text_raw_indices', 'aspect_indices', 'text_left_indices'],
        'bert_spc': ['text_bert_indices', 'attention_mask', 'bert_segments_ids'],
        'aen_bert': ['text_raw_bert_indices', 'target_bert_indices'],
        'lcf_bert': ['text_bert_indices', 'bert_segments_ids', 'text_raw_bert_indices', 'target_bert_indices'],
        'bert_lstm': ['text_bert_indices', 'bert_segments_ids', 'feature_bert_indices'],
        'lstm_gcn': ['text_indices', 'target_indices', 'in_graph'],
        'tan': ['text_indices', 'text_len', 'target_indices'],
        'han': ['text_indices', 'text_len', 'target_indices'],

    }
    initializers = {
        'xavier_uniform_': torch.nn.init.xavier_uniform_,
        'xavier_normal_': torch.nn.init.xavier_normal,
        'orthogonal_': torch.nn.init.orthogonal_,
    }
    optimizers = {
        'adadelta': torch.optim.Adadelta,  # default lr=1.0
        'adagrad': torch.optim.Adagrad,  # default lr=0.01
        'adam': torch.optim.Adam,  # default lr=0.001
        'adamax': torch.optim.Adamax,  # default lr=0.002
        'asgd': torch.optim.ASGD,  # default lr=0.01
        'rmsprop': torch.optim.RMSprop,  # default lr=0.01
        'sgd': torch.optim.SGD,
    }
    opt.model_class = model_classes[opt.model_name]
    opt.dataset_file = dataset_files[opt.dataset]
    opt.inputs_cols = input_colses[opt.model_name]
    opt.initializer = initializers[opt.initializer]
    opt.optimizer = optimizers[opt.optimizer]
    opt.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    # opt.device=torch.device('cpu')

    log_file = '{}-{}-{}.log'.format(opt.model_name, opt.dataset, strftime("%y%m%d-%H%M", localtime()))
    logger.addHandler(logging.FileHandler(modelPath + '/log/' + log_file))

    ins = Instructor(opt)
    ins.run()


if __name__ == '__main__':
    seed = 1
    random.seed(seed)
    numpy.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    main()
