# %% md

# Initial Setups

# %% md

## (Google Colab use only)


# %%


# Is this notebook running on Colab?
# If so, then google.colab package (github.com/googlecolab/colabtools)
# should be available in this environment

# Previous version used importlib, but we could do the same thing with
# just attempting to import google.colab


# %% md

## Experiment parameters

# %%

# We will use the following string ID to identify this particular (training) experiments
# in directory paths and other settings
import jieba
from sklearn import metrics

from bucket_iterator import BertBucketIterator, BRoBERTBucketIterator
from data_utils import ABSADataset, RoBERTaDataset

experiment_id = 'bert_prompt_logit_softmax_atsc_laptops_bert-base-uncased_multiple_prompts'

# Random seed
random_seed = 696
max_len = 128
# path to pretrained MLM model folder or the string "bert-base-uncased"
lm_model_path = './word-embedding/pretrain/torch-mlm-weibo'

# Prompts to be added to the end of each review text
# Note: pseudo-labels for each prompt should be given in the order of (positive), (negative), (neutral)
sentiment_prompts = [
    {"prompt": "我 - {aspect}。", "labels": [u"支持", u"反对", u"知道"]},
    {"prompt": "我 对于 {aspect} 的 态度 是 -。", "labels": ["支持", "反对", "中立"]},
    {"prompt": "我 认为 {aspect} - 。", "labels": ["好", "坏", "一般"]},
    {"prompt": "{aspect} 是 - 。", "labels": ["好", "坏", "一般"]}
]

# Multiple prompt merging behavior
prompts_merge_behavior = 'sum_logits'

# Perturb the input embeddings of tokens within the prompts
prompts_perturb = False

# Training settings
training_epochs = 1
training_batch_size = 16
training_learning_rate = 2e-5
training_weight_decay = 0.01
training_warmup_steps_duration = 0.15
training_hard_restart_num_cycles = 3
training_max_grad_norm = 1.0
training_best_model_criterion = 'train_loss'
training_domain = 'laptops'  # 'laptops', 'restaurants', 'joint'
training_dataset_proportion = 1.0
training_dataset_few_shot_size = None

training_lm_freeze = False

validation_enabled = False
validation_dataset_proportion = 0.2
validation_batch_size = 16

testing_batch_size = 16
testing_domain = 'laptops'  # 'laptops', 'restaurants', 'joint'

# %%

# Batch size adjustment for multiple prompts.
training_batch_size = training_batch_size // len(sentiment_prompts)

# %%

print("Experiment ID:", experiment_id)

# %% md

## Package imports

# %%

import sys
import os
import random
import shutil
import copy
import inspect
import json

import numpy as np
import torch
import transformers
import datasets
import sklearn.metrics
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sn
import tqdm
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

current_dir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parent_dir = os.path.dirname(current_dir)
sys.path.append(parent_dir)

import utils

# Random seed settings
random.seed(random_seed)
np.random.seed(random_seed)

# cuBLAS reproducibility
# https://docs.nvidia.com/cuda/cublas/index.html#cublasApi_reproducibility
os.environ['CUBLAS_WORKSPACE_CONFIG'] = ":4096:8"
# torch.set_deterministic(True)
torch.manual_seed(random_seed)

# Print version information
print("Python version: " + sys.version)
print("NumPy version: " + np.__version__)
print("PyTorch version: " + torch.__version__)
print("Transformers version: " + transformers.__version__)

# %% md

## PyTorch GPU settings

# %%

if torch.cuda.is_available():
    torch_device = torch.device('cuda')

    # Set this to True to make your output immediately reproducible
    # Note: https://pytorch.org/docs/stable/notes/randomness.html
    torch.backends.cudnn.deterministic = True

    # Disable 'benchmark' mode: Set this False if you want to measure running times more fairly
    # Note: https://discuss.pytorch.org/t/what-does-torch-backends-cudnn-benchmark-do/5936
    torch.backends.cudnn.benchmark = False

    # Faster Host to GPU copies with page-locked memory
    use_pin_memory = True

    # Number of compute devices to be used for training
    training_device_count = torch.cuda.device_count()

    # CUDA libraries version information
    print("CUDA Version: " + str(torch.version.cuda))
    print("cuDNN Version: " + str(torch.backends.cudnn.version()))
    print("CUDA Device Name: " + str(torch.cuda.get_device_name()))
    print("CUDA Capabilities: " + str(torch.cuda.get_device_capability()))
    print("Number of CUDA devices: " + str(training_device_count))

else:
    torch_device = torch.device('cpu')
    use_pin_memory = False

    # Number of compute devices to be used for training
    training_device_count = 1

print()
print("PyTorch device selected:", torch_device)





# Zero-shot ATSC with Prompts + MLM Output Head

# %% md

## Load the pretrained LM

# %%
from bert4keras.tokenizers import Tokenizer

# Load pretrained language model
lm = transformers.AutoModelForMaskedLM.from_pretrained(lm_model_path)
# 建立分词器
token_dict, keep_tokens, compound_tokens = json.load(
    open('tokenizer_config.json')
)

tokenizer = Tokenizer(
    token_dict,
    do_lower_case=True,
    pre_tokenize=lambda s: jieba.cut(s, HMM=False)
)
# %%

# Freeze the MLM main layer and leave the MLM head trainable
# Note: Since input and output word embeddings are tied,
# the output word embedding layer in lm.cls will remain untrainable
# https://github.com/huggingface/transformers/blob/master/src/transformers/configuration_utils.py#L170
if training_lm_freeze:
    for param in lm.cls.parameters():
        param.requires_grad = True

    for param in lm.bert.parameters():
        param.requires_grad = False

# %% md

## Define a new model with MLM output head

# %%

# Encode the pseudo-label words for each sentiment class
sentiment_word_ids = []

for sp in sentiment_prompts:
    sentiment_word_ids.append(
        [tokenizer.token_to_id(w) for w in sp['labels']])

print(sentiment_word_ids)

classifier_model = utils.MultiPromptLogitSentimentClassificationHead(
    lm=lm,
    num_class=3,
    num_prompts=len(sentiment_prompts), pseudo_label_words=sentiment_word_ids,
    target_token_id=tokenizer._token_mask_id,
    merge_behavior=prompts_merge_behavior,
    perturb_prompts=prompts_perturb)

classifier_model = classifier_model.to(device=torch_device)

# %% md

## Training settings

# %%
dataset_files = {
        'train': './datasets/weibo-train.raw',
        'test': './datasets/weibo-test.raw'
}
trainset = RoBERTaDataset(dataset_files['train'], tokenizer)
# self.valset = ABSADataset(opt.dataset_file['dev'], tokenizer)
testset = RoBERTaDataset(dataset_files['test'], tokenizer)

train_dataloader = BRoBERTBucketIterator(data=trainset, batch_size=training_batch_size, shuffle=True, sort_key='text')
validation_dataloader = BRoBERTBucketIterator(data=testset, batch_size=training_batch_size, shuffle=False, sort_key='text')

# %%

# How many training steps would we have?
training_total_steps = train_dataloader.batch_len * training_epochs

print("There will be %d training steps." % training_total_steps)

# Let's have warmups for the first (training_warmup_steps_duration)% of steps.
training_warmup_steps = int(training_total_steps * training_warmup_steps_duration)

print("Warmup steps:", training_warmup_steps)

# %%

loss_function = torch.nn.CrossEntropyLoss()

no_decay = ['bias', 'LayerNorm.weight']

optimizer_grouped_parameters = [
    {'params': [p for n, p in classifier_model.named_parameters() if not any(nd in n for nd in no_decay)],
     'weight_decay': training_weight_decay},
    {'params': [p for n, p in classifier_model.named_parameters() if any(nd in n for nd in no_decay)],
     'weight_decay': 0.0}
]

optimizer = transformers.AdamW(
    optimizer_grouped_parameters,
    lr=training_learning_rate,
    weight_decay=training_weight_decay)

scheduler = transformers.get_cosine_with_hard_restarts_schedule_with_warmup(
    optimizer,
    num_warmup_steps=training_warmup_steps,
    num_training_steps=training_total_steps,
    num_cycles=training_hard_restart_num_cycles
)

# The directory to save the best version of the head
trained_model_directory = os.path.join('..', 'trained_models', experiment_id)

shutil.rmtree(trained_model_directory, ignore_errors=True)
os.makedirs(trained_model_directory)


# %%

def compute_metrics(predictions, labels):
    preds = predictions.argmax(-1)
    y_trues = labels.detach().numpy()
    y_preds = preds.detach().numpy()
    f1_mac = metrics.f1_score(y_trues, y_preds, labels=[0, 2], average='macro')
    acc_sk = metrics.accuracy_score(y_trues, y_preds)
    precision = metrics.precision_score(y_trues, y_preds, labels=[0, 2], average='macro')
    recall = metrics.recall_score(y_trues, y_preds, labels=[0, 2], average='macro')
    class_result = metrics.classification_report(y_trues, y_preds, target_names=['反对', '中立', '支持'], digits=4)
    print(class_result)
    print(
        '>> test_acc: {:.4f}, test_precision:{:.4f}, test_recall:{:.4f}, test_f1: {:.4f}'.format(acc_sk, precision,
                                                                                                 recall, f1_mac))
    return {
        'accuracy': acc_sk,
        'f1': f1_mac,
        'precision': precision,
        'recall': recall
    }


def woBERTtokenizer(texts, targets):
    input_ids, token_type_ids, attention_mask = [], [], []
    for i in range(0, len(texts)):
        charId = tokenizer.token_to_id('-')
        token_ids, segment_ids = tokenizer.encode(texts[i], targets[i], maxlen=max_len)
        # 添加[MASK]
        for j in range(len(token_ids) - 1, -1, -1):
            if token_ids[j] == charId:
                token_ids[j] = tokenizer._token_mask_id
        token_ids_padding = [0] * (max_len - len(token_ids))
        segment_ids_padding = [0] * (max_len - len(segment_ids))
        token_ids_pad = token_ids + token_ids_padding
        input_ids.append(token_ids_pad)

        segment_ids = segment_ids + segment_ids_padding
        token_type_ids.append(segment_ids)

        mask = [1] * len(token_ids) + token_ids_padding
        attention_mask.append(mask)
        # print(token_ids)
        # print(segment_ids)
        # print(mask)

    return {
        'input_ids': torch.tensor(input_ids),
        'token_type_ids': torch.tensor(token_type_ids),
        'attention_mask': torch.tensor(attention_mask)
    }

# %% md

## Training loop

# %%

best_epoch = -1

if training_best_model_criterion in ('train_loss', 'valid_loss'):
    best_score = float('inf')
else:
    best_score = -1

for epoch in tqdm.tqdm(range(int(training_epochs))):

    print("Training epoch %d" % epoch)
    print()

    classifier_model.train()
    predictions_train = torch.Tensor()
    labels_train = torch.Tensor()

    for i_batch, batch in tqdm.tqdm(enumerate(train_dataloader)):

        reviews_repeated = []
        prompts_populated = []

        for prompt in sentiment_prompts:
            reviews_repeated = reviews_repeated + batch["text"]

            for aspect in batch["target"]:
                prompts_populated.append(prompt['prompt'].format(aspect=aspect))
        # print("reviews_repeated:{}".format(reviews_repeated))
        # print("prompts_populated:{}".format(prompts_populated))

        batch_encoded = woBERTtokenizer(reviews_repeated, prompts_populated)

        batch_en = [batch_encoded[col].to(torch_device) for col in ['input_ids', 'token_type_ids', 'attention_mask']]
        batch_encoded = {'input_ids': batch_en[0], 'token_type_ids': batch_en[1], 'attention_mask': batch_en[2]}
        batch_label = batch["stance"]
        batch_label = torch.tensor(batch_label)
        batch_label = batch_label.to(torch_device)

        optimizer.zero_grad()

        batch_output = classifier_model(batch_encoded)

        loss = loss_function(batch_output, batch_label)
        batch_output = batch_output.to('cpu')
        batch_label = batch_label.to('cpu').float()

        loss.backward()
        torch.nn.utils.clip_grad_norm_(classifier_model.parameters(), training_max_grad_norm)

        optimizer.step()
        scheduler.step()

        predictions_train = torch.cat([predictions_train, batch_output])
        labels_train = torch.cat([labels_train, batch_label])

    # Compute metrics
    compute_metrics(predictions_train, labels_train)

    print("Epoch {}, Training Loss: {}".format(epoch, loss.item()))
    print()

    # Validate the model using val dataset
    if validation_enabled:
        with torch.no_grad():
            classifier_model.eval()

            print("Validation epoch %d" % epoch)
            print()

            predictions_val = torch.Tensor()
            labels_val = torch.Tensor()

            for batch_val in tqdm.tqdm(validation_dataloader):

                reviews_repeated = []
                prompts_populated = []

                for prompt in sentiment_prompts:
                    reviews_repeated = reviews_repeated + batch_val["text"]

                    for aspect in batch_val["aspect"]:
                        prompts_populated.append(prompt['prompt'].format(aspect=aspect))


                batch_val_encoded = woBERTtokenizer(reviews_repeated, prompts_populated)

                batch_val_en = [batch_val_encoded[col].to(torch_device) for col in
                            ['input_ids', 'token_type_ids', 'attention_mask']]
                batch_val_encoded = {'input_ids': batch_val_en[0], 'token_type_ids': batch_val_en[1], 'attention_mask': batch_val_en[2]}

                batch_val_label = float(batch_val["sentiment"])

                batch_val_output = classifier_model(batch_val_encoded)

                batch_val_output = batch_val_output.to('cpu')

                predictions_val = torch.cat([predictions_val, batch_val_output])
                labels_val = torch.cat([labels_val, batch_val_label])

            # Compute metrics
            validation_loss = torch.nn.functional.cross_entropy(predictions_val, labels_val.long())
            validation_metrics = compute_metrics(predictions_val, labels_val)

            print("Validation Loss: {}, Validation Metrics: {}".format(validation_loss.item(), validation_metrics))
            print()

    if training_best_model_criterion == 'train_loss':
        epoch_score = loss.item()
    elif training_best_model_criterion == 'valid_loss':
        epoch_score = validation_loss.item()

    if training_best_model_criterion in ('train_loss', 'valid_loss'):
        better_model_found = epoch_score < best_score
    else:
        better_model_found = epoch_score > best_score

    # Save the current epoch's model if the validation loss is lower than the best known so far
    if better_model_found:
        if best_epoch != -1:
            try:
                os.remove(os.path.join(trained_model_directory, 'epoch_{}.pt'.format(best_epoch)))
            except:
                pass

        best_score = epoch_score
        best_epoch = epoch

        torch.save(
            classifier_model.state_dict(),
            os.path.join(trained_model_directory, 'epoch_{}.pt'.format(epoch)))

# %% md

## Evaluation with in-domain test set


# %%



# %%

# Load the best found head weights
with torch.no_grad():
    print('Loading epoch {}'.format(best_epoch))

    classifier_model.load_state_dict(torch.load(
        os.path.join(trained_model_directory, 'epoch_{}.pt'.format(best_epoch)),
        map_location=torch_device))

    classifier_model.eval()

    predictions_test = torch.Tensor()
    labels_test = torch.Tensor()

    for i_batch, batch_test in tqdm.tqdm(enumerate(validation_dataloader)):

        reviews_repeated = []
        prompts_populated = []

        for prompt in sentiment_prompts:
            reviews_repeated = reviews_repeated + batch_test["text"]

            for aspect in batch_test["target"]:
                prompts_populated.append(prompt['prompt'].format(aspect=aspect))



        batch_test_encoded = woBERTtokenizer(reviews_repeated, prompts_populated)

        batch_test_en = [batch_test_encoded[col].to(torch_device) for col in
                        ['input_ids', 'token_type_ids', 'attention_mask']]
        batch_test_encoded = {'input_ids': batch_test_en[0], 'token_type_ids': batch_test_en[1],
                             'attention_mask': batch_test_en[2]}

        batch_test_label = batch_test["stance"]
        batch_test_label = torch.tensor(batch_test_label)
        batch_test_label = batch_test_label.to('cpu').float()

        batch_test_output = classifier_model(batch_test_encoded)

        batch_test_output = batch_test_output.to('cpu')

        predictions_test = torch.cat([predictions_test, batch_test_output])
        labels_test = torch.cat([labels_test, batch_test_label])

    # Compute metrics
    test_metrics = compute_metrics(predictions_test, labels_test)

    print(test_metrics)

    # Save test_metrics into a file for later processing
    with open(os.path.join(trained_model_directory, 'test_metrics.json'), 'w') as test_metrics_json:
        json.dump(test_metrics, test_metrics_json)

# %% md

## Results visualization

# %%

# Calculate metrics and confusion matrix based upon predictions and true labels
cm = sklearn.metrics.confusion_matrix(labels_test.detach().numpy(), predictions_test.detach().numpy().argmax(-1))

df_cm = pd.DataFrame(
    cm,
    index=[i for i in ["positive", "negative", "neutral"]],
    columns=[i for i in ["positive", "negative", "neutral"]])

plt.figure(figsize=(10, 7))

ax = sn.heatmap(df_cm, annot=True)

ax.set(xlabel='Predicted Label', ylabel='True Label')
plt.show()
