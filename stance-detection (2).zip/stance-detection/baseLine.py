import sys
# from pandas import DataFrame
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier

from xgboost import XGBClassifier

sys.path.append('external-libraries')
import argparse
import os

import numpy as np
import pandas as pd
import jieba
from gensim.models import Word2Vec
import paddle.fluid.dygraph as D
from sklearn import metrics
from visualdl import LogWriter
from sklearn.svm import SVC

# import time
# from sklearn.externals import joblib
# import cv2

BATCH = 32
SEED = 1
np.random.seed(SEED)


def load_data(filename):
    texts, labels = [], []
    with open(filename, 'r', encoding='utf8') as train:
        for line in train:
            if len(line.split("\t")) != 4: continue
            line = line.replace('\n', '').replace('\r', '')
            if line.split("\t")[2] == 'TEXT': continue

            if line.split("\t")[3] == "FAVOR":
                stance = 2
            elif line.split("\t")[3] == "AGAINST":
                stance = 0
            else:
                stance = 1
            texts.append(line.split("\t")[2][:110])
            labels.append(stance)

    return texts, labels


#  载入数据，做预处理(分词)，切分训练集与测试集
def load_file_and_preprocessing():
    # cw = lambda x: list(jieba.cut(x))

    x_train, y_train = load_data('/home/ws/stance-detection/datasets/Z-stance-train2.txt')
    x_test, y_test = load_data('/home/ws/stance-detection/datasets/Z-stance-dev.txt')
    x_train = [list(jieba.cut(x)) for x in x_train]
    x_test = [list(jieba.cut(x)) for x in x_test]

    # print(x_train)

    return np.array(x_train), np.array(x_test), np.array(y_train), np.array(y_test)


# 对每个句子的所有词向量取均值，来生成一个句子的vector
def build_sentence_vector(text, size, imdb_w2v):
    vec = np.zeros(size).reshape((1, size))
    count = 0.
    for word in text:
        try:
            vec += imdb_w2v[word].reshape((1, size))
            count += 1.
        except KeyError:
            continue
    if count != 0:
        vec /= count
    return vec


# 计算词向量
def get_train_vecs():
    x_train, x_test, y_train, y_test = load_file_and_preprocessing()
    n_dim = 300
    # 初始化模型和词表
    imdb_w2v = Word2Vec(x_train, size=n_dim, min_count=10)
    # imdb_w2v = Word2Vec(size=300, window=5, min_count=10, workers=12)
    # imdb_w2v.build_vocab(x_train)
    #
    # imdb_w2v.train(x_train,
    #                total_examples=imdb_w2v.corpus_count,
    #                epochs=imdb_w2v.iter)

    train_vecs = np.concatenate([build_sentence_vector(z, n_dim, imdb_w2v) for z in x_train])
    # train_vecs = scale(train_vecs)

    # np.save('svm_data/train_vecs.npy', train_vecs)
    print(train_vecs.shape)

    # 在测试集上训练
    # imdb_w2v.train(x_test, total_examples=len(x_test))
    imdb_w2v.train(x_test,
                   total_examples=imdb_w2v.corpus_count,
                   epochs=imdb_w2v.iter)

    # imdb_w2v.save('svm_data/w2v_model/w2v_model.pkl')
    # Build test tweet vectors then scale
    test_vecs = np.concatenate([build_sentence_vector(z, n_dim, imdb_w2v) for z in x_test])
    # test_vecs = scale(test_vecs)
    # np.save('svm_data/test_vecs.npy', test_vecs)
    print(test_vecs.shape)

    return train_vecs, test_vecs, y_train, y_test




def softmax(x):
    """ softmax function """
    x -= np.max(x, axis=1, keepdims=True)  # 为了稳定地计算softmax概率， 一般会减掉最大的那个元素
    x = np.exp(x) / np.sum(np.exp(x), axis=1, keepdims=True)
    return x


def eval_each_target(y_trues, y_preds):
    target_list = ['CJ_T2', 'SE_T1', 'FK_T3', 'ET_T4', 'SZ_T5']
    count = 0
    for i in range(0, len(y_trues), 200):
        f1_mac = metrics.f1_score(y_trues[i:i+200], y_preds[i:i+200], labels=[0, 2], average='macro')
        print('{}:'.format(target_list[count]))
        print(u'val_f1: %.4f\n' % (f1_mac))
        count = count + 1

def eval_each_target_Z_stance(y_trues, y_preds):
    import pandas as pd
    # target_list = ['CJ_T2', 'SE_T1', 'FK_T3', 'ET_T4', 'SZ_T5']
    target_name_list = ['三胎生育政策来了', '俄乌冲突', '华为鸿蒙', '滴滴下架']
    target_list = []
    i = 0
    with open('/home/ws/stance-detection/datasets/Z-stance-dev.txt', 'r', encoding='utf8') as train:
        for line in train:
            if len(line.split("\t")) != 4: continue
            line = line.replace('\n', '').replace('\r', '')
            # if line == 'TARGET':
            #     continue

            target_list.append(line.split("\t")[1])

    data = {'target': target_list[1:],
            'y_trues': y_trues,
            'y_preds': y_preds
            }
    df = pd.DataFrame(data)
    for item in target_name_list:
        df_target = df[df['target'] == item]
        f1_mac = metrics.f1_score(df_target['y_trues'], df_target['y_preds'], labels=[0, 2], average='macro')
        print('{}:'.format(item))
        print(u'val_f1: %.4f\n' % (f1_mac))
        # class_result = metrics.classification_report(df_target['y_trues'], df_target['y_preds'], target_names=['反对', '中立', '支持'], digits=4)
        # print(class_result)

def model_performance(test_true, test_pred, test_score_convert):
    # print("test_score_convert = {}".format(test_score_convert.tolist()))
    # y_scores = softmax(test_score_convert.tolist())
    # for item in test_score_convert:
    #     y_scores.append()

    # test_accuracy = metrics.accuracy_score(test_true, test_pred)
    # test_precision = metrics.precision_score(test_true, test_pred, average='macro')
    # test_recall = metrics.recall_score(test_true, test_pred, average='macro')
    # test_f1 = metrics.f1_score(test_true, test_pred, average='macro')
    # print("Acc: %.4f, Precision: %.4f, Recall: %.4f, F1: %.4f"
    #       % (test_accuracy, test_precision, test_recall, test_f1))

    y_trues = test_true
    y_preds = test_pred
    f1_mac = metrics.f1_score(y_trues, y_preds, labels=[0, 2], average='macro')
    f1_mic = metrics.f1_score(y_trues, y_preds, labels=[0, 2], average='micro')

    acc_sk = metrics.accuracy_score(y_trues, y_preds)
    precision = metrics.precision_score(y_trues, y_preds, labels=[0, 2], average='macro')
    recall = metrics.recall_score(y_trues, y_preds, labels=[0, 2], average='macro')
    class_result = metrics.classification_report(y_trues, y_preds, target_names=['反对', '中立', '支持'], digits=4)
    print(class_result)
    print(
        '>> test_acc: {:.4f}, test_precision:{:.4f}, test_recall:{:.4f}, test_f1_mac: {:.4f}, test_f1_mic: {:.4f}'.format(
            acc_sk, precision,
            recall, f1_mac, f1_mic))

    eval_each_target_Z_stance(y_trues, y_preds)
    # eval_each_target(y_trues, y_preds)





def svm_train(text, labels, test_text, test_labels):
    clf = SVC(kernel='linear', decision_function_shape='ovr', max_iter=1)
    clf.fit(text, labels)
    # joblib.dump(clf, '/home/ws/fake_news_detection/model/svm/model.pkl')
    y_test = clf.predict(test_text)

    test_score_convert = clf.decision_function(test_text)
    test_pred = y_test
    model_performance(test_labels, test_pred, test_score_convert)


def lr_train(text, labels, test_text, test_labels):
    clf = LogisticRegression()
    clf.fit(text, labels)
    # joblib.dump(clf, '/home/ws/fake_news_detection/model/lr/model.pkl')
    y_test = clf.predict(test_text)

    test_score_convert = clf.decision_function(test_text)
    test_pred = y_test
    model_performance(test_labels, test_pred, test_score_convert)


def rf_train(text, labels, test_text, test_labels):
    clf = RandomForestClassifier()
    clf.fit(text, labels)
    # joblib.dump(clf, '/home/ws/fake_news_detection/model/rf/model.pkl')
    y_test = clf.predict(test_text)


    test_score_convert = clf.predict_proba(test_text)
    test_pred = y_test
    model_performance(test_labels, test_pred, test_score_convert)


def bp_train(text, labels, test_text, test_labels):
    clf = MLPClassifier(hidden_layer_sizes=(50, 50), random_state=1, alpha=1e-4)
    clf.fit(text, labels)
    # joblib.dump(clf, '/home/ws/fake_news_detection/model/bp/model.pkl')
    y_test = clf.predict(test_text)

    test_score_convert = clf.predict_proba(test_text)
    test_pred = y_test
    model_performance(test_labels, test_pred, test_score_convert)


def xgb_train(text, labels, test_text, test_labels):
    clf = XGBClassifier(max_depth=6, learning_rate=0.1, n_estimators=100, silent=True)
    clf.fit(text, labels)
    # joblib.dump(clf, '/home/ws/fake_news_detection/model/bp/model.pkl')
    y_test = clf.predict(test_text)

    test_score_convert = clf.predict_proba(test_text)
    test_pred = y_test
    model_performance(test_labels, test_pred, test_score_convert)



# sortedTrain = pd.read_csv('/home/ws/stance-detection/datasets/Z-stance.csv')
# all_data = make_data()
# np.random.shuffle(all_data)
# eval_data = all_data[-(len(all_data)) // 5:]
# train_data = all_data[(len(all_data)) // 5:-(len(all_data)) // 5]


with LogWriter(logdir="logs/log-eann") as writer:
    print('training model')
    # np.random.shuffle(train_data)

    train_vecs, test_vecs, train_labels, validate_labels = get_train_vecs()


    train_input = train_vecs
    test_input = test_vecs
    # print("test_true = {}".format(validate_labels.tolist()))

    # print('\n>>>>>>>>>>>>  SVM   >>>>>>>>>>>>>')
    # svm_train(train_input, train_labels, test_input, validate_labels)
    print('\n>>>>>>>>>>>>  LR   >>>>>>>>>>>>>')
    lr_train(train_input, train_labels, test_input, validate_labels)
    print('\n>>>>>>>>>>>>  RF   >>>>>>>>>>>>>')
    rf_train(train_input, train_labels, test_input, validate_labels)
    print('\n>>>>>>>>>>>>  BP   >>>>>>>>>>>>>')
    bp_train(train_input, train_labels, test_input, validate_labels)
    print('\n>>>>>>>>>>>>  XGBoost  >>>>>>>>>>>>>')
    xgb_train(train_input, train_labels, test_input, validate_labels)

