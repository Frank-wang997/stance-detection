
import numpy as np
import json
from bert4keras.tokenizers import Tokenizer
import jieba

token_dict, keep_tokens, compound_tokens = json.load(
    open('tokenizer_config.json')
)

tokenizer = Tokenizer(
    token_dict,
    do_lower_case=True,
    pre_tokenize=lambda s: jieba.cut(s)
)
# 获取每个目标的seed_word
def load_seed_word(path, weightFilter=0.5):
    seed_words = {}
    words = []
    fp = open(path, 'r')
    for line in fp:
        line = line.strip()
        if not line:
            continue
        word, weight = line.split('\t')
        if float(weight) < weightFilter:
            continue
        words.append(word)
        seed_words[word] = weight
    fp.close()
    return words

all_words_seed = []
all_words_seed.append(load_seed_word('seed_words/seed_word.SE.label.stance'))
all_words_seed.append(load_seed_word('seed_words/seed_word.CJ.label.stance'))
all_words_seed.append(load_seed_word('seed_words/seed_word.FK.label.stance'))
all_words_seed.append(load_seed_word('seed_words/seed_word.ET.label.stance'))
all_words_seed.append(load_seed_word('seed_words/seed_word.SZ.label.stance'))

TARGET_DIC = {'iphonese': all_words_seed[0], '春节放鞭炮': all_words_seed[1], '俄罗斯叙利亚反恐行动': all_words_seed[2], '开放二胎': all_words_seed[3], '深圳禁摩限电': all_words_seed[4]}



def target_masking(token_ids, text_target):
    """对输入进行关键词mask
    """
    source, target = [], []
    token_len = len(token_ids)
    # sentence_list = list(range(1, token_len))

    # is_topic = []
    seeds = TARGET_DIC[text_target]
    seed_ids = tokenizer.tokens_to_ids(seeds)
    # for t in token_ids:
    #     if t in seed_ids:
    #         is_topic.append(0)
    #     else:
    #         is_topic.append(1)

    # count = 0
    # mask_len = round(token_len * 0.15)


    # print(tokenizer.ids_to_tokens(seed_ids))
    # print(seed_ids)

    rands = np.random.random(len(token_ids))
    for r, t in zip(rands, token_ids):
        if t in seed_ids:
            source.append(tokenizer._token_mask_id)
            target.append(t)
        else:
            source.append(t)
            target.append(0)
    # print("MASK后：")
    # print(tokenizer.ids_to_tokens(source))
    # print(tokenizer.ids_to_tokens(target))

