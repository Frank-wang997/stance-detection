import jieba


def load_seed_word(path):
    seed_words = {}
    words = []
    fp = open(path, 'r')
    for line in fp:
        line = line.strip()
        if not line:
            continue
        word, weight = line.split('\t')
        if float(weight) < 0.5:
            continue
        words.append(word)
        seed_words[word] = weight
    fp.close()
    return words


# ET_seed = load_seed_word('./seed_word.ET.stance')
# CJ_seed = load_seed_word('./seed_word.CJ.stance')
# FK_seed = load_seed_word('./seed_word.FK.stance')
# SE_seed = load_seed_word('./seed_word.SE.stance')
# SZ_seed = load_seed_word('./seed_word.SZ.stance')
#
# TARGET_DIC = {'iphonese': SE_seed, '春节放鞭炮': CJ_seed, '俄罗斯叙利亚反恐行动': FK_seed, '开放二胎': ET_seed, '深圳禁摩限电': SZ_seed}
#
# a = sorted(seed_all.items(), key=lambda x: x[1], reverse=True)
jieba.initialize()
a = sorted(jieba.dt.FREQ.items(), key=lambda s: -s[1])
print(a)

