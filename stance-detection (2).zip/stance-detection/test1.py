import numpy as np

# # 1
# image = [[(col + 1) * (row + 1) for col in range(5)] for row in range(3)]
# a = np.array(image)
# print(a)
#
# # 2
# new_image = np.zeros((3, 5))

# 3
b = np.arange(12).reshape(3, 4)
print(b)
print(b[1, [2, 1]])
