import os

# modelPath = os.path.dirname(os.path.realpath(__file__))
# print(modelPath)
# from sklearn import metrics

print(1)


def eval_each_target(y_trues, y_preds):
    target_list = ['CJ', 'SE', 'FK', 'ET', 'SZ']
    count = 0
    for i in range(0, len(y_trues), 2):

        f1_mac = metrics.f1_score(y_trues[i:i+2], y_preds[i:i+2], labels=[0, 2], average='macro')
        print('{}:'.format(target_list[count]))
        print(u'val_f1: %.4f\n' % (f1_mac))
        count = count + 1

t = [1, 0, 2, 1, 1, 0, 2, 1, 1, 1]
p = [1, 1, 1, 1, 1, 0, 1, 1, 0, 1]
# eval_each_target(t, p)

if __name__ == '__main__':
    print(2)
