import random
import re
import pandas as pd


SEED = 1
random.seed(SEED)

def preprocess(sentence):
    tidyText = re.sub(r'(https|http)?:\/\/(\w|\.|\/|\?|\=|\&|\%)*\b', '', sentence, flags=re.MULTILINE)
    return tidyText




if __name__ == '__main__':
    df = pd.read_csv('final.csv')
    i = 0
    sentence = ''
    stance = ''
    rowTxt = []
    for index, row in df.iterrows():
        df.sample(frac=1).reset_index(drop=True)
        if row['FAVOUR'] == 1:
            stance = 'FAVOR'
        elif row['AGAINST'] == 1:
            stance = 'AGAINST'
        elif row['NONE'] == 1:
            stance = 'NONE'
        i += 1
        sentence = str(i) + '\t共产党\t' + preprocess(row['content']).strip() + '\t' + stance
        print(sentence)
        rowTxt.append(sentence)

    random.shuffle(rowTxt)
    trainSet = int(len(rowTxt) * 0.8)
    devSet = int(len(rowTxt) * 0.2)
    with open('GCD-train-80%-raw.txt', 'w', encoding='utf_8_sig') as f:
        # 文件头部
        f.write('ID	TARGET	TEXT	STANCE')
        f.write('\n')

        for j in range(trainSet):
            f.write(rowTxt[j])
            f.write('\n')
    with open('GCD-dev-20%-raw.txt', 'w', encoding='utf_8_sig') as f:
        # 文件头部
        f.write('ID	TARGET	TEXT	STANCE')
        f.write('\n')

        for j in range(devSet):
            f.write(rowTxt[j+trainSet])
            f.write('\n')


