import pandas as pd



def split_train_and_dev():
    pass



if __name__ == '__main__':
    pass