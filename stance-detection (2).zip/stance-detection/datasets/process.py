#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
@Author: BillyZhang24kobe
@Date: 2020-07-13 20:16:37
@LastEditTime: 2020-07-18 17:28:41
@LastEditors: BillyZhang24kobe
@Description: Process a raw dataset into a sample file.
@FilePath: /stance-detection/data/process.py
'''

import sys
import os
import pathlib

import json
import jieba

# 添加分词
# keyWord_anti_china = ['自由门', '无界浏览', '法轮功', '法轮大法', '法轮佛法', 'falun gong', 'freegate', 'ultrasurf']
# keyWord_vpn = ['vpn', '翻墙', '科学上网', 'GFW', 'shadowsocks', 'v2ray', 'ss', '机场', '梯子', '#ss', 'ssr']
# keyWord_GCD = ['共产党', '中共', '小粉红']
# keyWords = keyWord_anti_china + keyWord_vpn + keyWord_GCD
# for word1 in keyWords:
#     jieba.add_word(word1)

abs_path = pathlib.Path(__file__).parent.absolute()
sys.path.append(sys.path.append(abs_path))
from data_utils import write_samples, partition

train_samples = set()
dev_samples = set()
# Read text file
train_file_path = os.path.join(abs_path, 'Z-stance-train.txt')
dev_file_path = os.path.join(abs_path, 'Z-stance-dev.txt')

# process train file
with open(train_file_path, 'r', encoding='utf8') as train:
    for line in train:
        if len(line.split("\t")) != 4: continue
        line = line.replace('\n', '').replace('\r', '')
        target = ' '.join(list(jieba.cut(line.split("\t")[1])))
        text = ' '.join(list(jieba.cut(line.split("\t")[2])))
        if line.split("\t")[3] == "FAVOR":
            stance = 1
        elif line.split("\t")[3] == "AGAINST":
            stance = -1
        else:
            stance = 0
        # stance = line.split("\t")[3]
        t_sample = text + '\n' + target + '\n' + str(stance)
        train_samples.add(t_sample)
train_write_path = os.path.join(abs_path, 'Z-stance-train.raw')
write_samples(train_samples, train_write_path)

# process test file
with open(dev_file_path, 'r', encoding='utf8') as dev:
    for line in dev:
        if len(line.split("\t")) != 4: continue
        line = line.replace('\n', '').replace('\r', '')
        target = ' '.join(list(jieba.cut(line.split("\t")[1])))
        text = ' '.join(list(jieba.cut(line.split("\t")[2])))
        if line.split("\t")[3] == "FAVOR":
            stance = 1
        elif line.split("\t")[3] == "AGAINST":
            stance = -1
        else:
            stance = 0
        # stance = line.split("\t")[3]
        d_sample = text + '\n' + target + '\n' + str(stance)
        dev_samples.add(d_sample)
dev_write_path = os.path.join(abs_path, 'Z-stance-dev.raw')
write_samples(dev_samples, dev_write_path)
