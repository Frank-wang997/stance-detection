# remove weibo stop words in files
# from data_utils import write_samples

# stopwords file
f_stopwords = open('weibo_stopwords.txt', 'r', encoding='utf-8')
sw = f_stopwords.readlines()
f_stopwords.close()

stopwords = []
for line in sw:
    line = line.replace('\n', '')
    stopwords.append(line)

# train file or dev file
trainFileIn = 'GCD-train-80%-seg.txt'
trainFileOut = 'GCD-train-80%-seg-rmstopwords.txt'
devFileIn = 'GCD-dev-20%-seg.txt'
devFileOut = 'GCD-dev-20%-seg-rmstopwords.txt'


def removeStopWords(In,Out):
    fin = open(In, 'r', encoding='utf-8')
    lines = fin.readlines()
    fin.close()

    for i in range(0, len(lines), 3):
        lines[i] = lines[i].replace('\n', '')
        new_line = ""
        for w in lines[i].split(' '):
            if w not in stopwords:
                new_line += w + ' '
        new_line += '\n'
        lines[i] = new_line

    with open(Out, 'w', encoding='utf-8') as file:
        for line in lines:
            file.write(line)


if __name__ == '__main__':
    removeStopWords(trainFileIn, trainFileOut)
    removeStopWords(devFileIn, devFileOut)


