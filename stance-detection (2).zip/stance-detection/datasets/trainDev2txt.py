import random
import re

import pandas as pd


def preprocess(sentence):
    tidyText = re.sub(r'(https|http)?:\/\/(\w|\.|\/|\?|\=|\&|\%)*\b', '', sentence, flags=re.MULTILINE)
    tidyText = re.sub('[a-zA-Z]', '', tidyText)
    tidyText = tidyText.replace("？？", "？?").replace("?", "").replace(" ", "")
    return tidyText


def csv2txt(df, txtName):
    i = 0
    sentence = ''
    stance = ''
    rowTxt = []
    for index, row in df.iterrows():
        if row['FAVOUR'] == 1:
            stance = 'FAVOR'
        elif row['AGAINST'] == 1:
            stance = 'AGAINST'
        elif row['NONE'] == 1:
            stance = 'NONE'
        i += 1
        sentence = str(i) + '\t法轮功\t' + preprocess(row['content']).strip() + '\t' + stance
        rowTxt.append(sentence)
    trainSet = int(len(rowTxt))
    random.shuffle(rowTxt)
    with open(txtName, 'w', encoding='utf_8_sig') as f:
        # 文件头部
        f.write('ID	TARGET	TEXT	STANCE')
        f.write('\n')

        for j in range(trainSet):
            f.write(rowTxt[j])
            f.write('\n')


if __name__ == '__main__':
    df_train = pd.read_csv('train.csv')
    txtTarin = 'train-80%-raw.txt'
    csv2txt(df_train, txtTarin)

    df_dev = pd.read_csv('dev.csv')
    txtDev = 'dev-20%-raw.txt'
    csv2txt(df_dev, txtDev)






