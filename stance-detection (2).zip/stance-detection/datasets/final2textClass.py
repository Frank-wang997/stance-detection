import random
import re

import pandas as pd


def preprocess(sentence):
    tidyText = re.sub(r'(https|http)?:\/\/(\w|\.|\/|\?|\=|\&|\%)*\b', '', sentence, flags=re.MULTILINE).replace(" ", "")
    tidyText = tidyText.replace("？？", "？?").replace("?", "")

    return tidyText


if __name__ == '__main__':
    df = pd.read_csv('final.csv')
    i = 0
    sentence = ''
    stance = ''
    rowTxt = []
    for index, row in df.iterrows():
        df.sample(frac=1).reset_index(drop=True)
        if row['FAVOUR'] == 1:
            stance = 1
        elif row['AGAINST'] == 1:
            stance = 0
        elif row['NONE'] == 1:
            stance = 2
        i += 1
        sentence = preprocess(row['content']).strip() + '\t' + str(stance)
        print(sentence)
        rowTxt.append(sentence)
    random.shuffle(rowTxt)
    trainSet = int(len(rowTxt) * 0.8)
    devSet = int(len(rowTxt) * 0.2)
    with open('train.txt', 'w', encoding='utf_8_sig') as f:
        for j in range(trainSet):
            f.write(rowTxt[j])
            f.write('\n')
    with open('dev.txt', 'w', encoding='utf_8_sig') as f:
        for j in range(devSet):
            f.write(rowTxt[j+trainSet])
            f.write('\n')


