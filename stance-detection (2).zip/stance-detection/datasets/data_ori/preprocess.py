import random

import pandas as pd
import re
from zhconv import convert

def Traditional2Simplified(sentence):
    '''
    将sentence中的繁体字转为简体字
    :param sentence: 待转换的句子
    :return: 将句子中繁体字转换为简体字之后的句子
    '''
    sentence = convert(sentence, 'zh-hans')
    return sentence


def sub_url(s):
    """
    Delete web links
    """

    s = re.sub(r"\s+", "", s)
    # print(s)
    # 删除http网址
    s = re.sub(
        r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_…@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+', "", s)
    # 删除pic网址
    s = re.sub(
        r'pic(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+', "", s)
    return s


def rm_html(text_content):
    # 过滤文本中的html链接等
    re_tag = re.compile('</?\w+[^>]*>')  # HTML标签
    new_text = re.sub(re_tag, '', text_content)
    new_text = re.sub(",+", ",", new_text)  # 合并逗号
    # new_text = re.sub(" +", " ", new_text)  # 合并空格
    new_text = re.sub("[...|…|。。。]+", "...", new_text)  # 合并句号
    # new_text = re.sub("-+", "--", new_text)  # 合并-
    text_content = re.sub("———+", "———", new_text)  # 合并-
    return text_content

def rm_name(content):
    # 过滤人名
    content = re.sub('@[\\u4e00-\\u9fa5\\w\\-]+', '', content)

    return content


def cleanDataByTXT(raw_data, cleaned_data):
    fin = open(raw_data, 'r', encoding='utf-8_sig', errors='ignore')
    i = -1
    rowTxt = []
    for line in fin:
        line = line.strip()
        if not line:
            continue
        item = line.split('\t')
        target = item[1]
        target = target
        target = target.lower()
        stance = item[-1]
        text1 = ' '.join(item[2:-1])
        text = rm_name(text1)
        text = sub_url(text)
        text = rm_html(text)
        text = Traditional2Simplified(text)

        i = i + 1
        sentence = str(i) + '\t' + target + '\t' + text + '\t' + stance

        rowTxt.append(sentence)

    with open(cleaned_data, 'w', encoding='utf-8_sig') as f:
        # 文件头部
        f.write('ID	TARGET	TEXT	STANCE')
        f.write('\n')

        for j in range(len(rowTxt)):
            f.write(rowTxt[j])
            f.write('\n')

def cleanDataByDF(fileName):

    df = pd.read_csv(fileName)
    rowTxt = []
    i = 0
    for index, row in df.iterrows():
        target = row['target']
        target = str(target)

        # if target == '' or target is None or target == 'nan':
        #     target = '俄乌战争'
        stance = row['stance']
        text1 = row['content']
        text = rm_name(text1)
        text = sub_url(text)
        text = rm_html(text)
        text = Traditional2Simplified(text)
        i = i + 1
        sentence = str(i) + '\t' + target + '\t' + text + '\t' + stance
        print(sentence)
        rowTxt.append(sentence)

    random.shuffle(rowTxt)
    trainSet = int(len(rowTxt) * 0.8)
    devSet = int(len(rowTxt) * 0.2)
    with open('Z-stance-ext.txt', 'w', encoding='utf_8_sig') as f:
        # 文件头部
        f.write('ID	TARGET	TEXT	STANCE')
        f.write('\n')

        for j in range(trainSet):
            f.write(rowTxt[j])
            f.write('\n')
    with open('Z-stance-dev.txt', 'w', encoding='utf_8_sig') as f:
        # 文件头部
        f.write('ID	TARGET	TEXT	STANCE')
        f.write('\n')

        for j in range(devSet):
            f.write(rowTxt[j + trainSet])
            f.write('\n')

def cleanDataByDF_NOLABEL(fileName):

    df = pd.read_csv(fileName)
    rowTxt = []
    i = 0
    for index, row in df.iterrows():
        target = row['target']
        target = str(target)

        # if target == '' or target is None or target == 'nan':
        #     target = '俄乌战争'
        # stance = row['stance']
        text1 = row['content']
        text = rm_name(text1)
        text = sub_url(text)
        text = rm_html(text)
        text = Traditional2Simplified(text)
        i = i + 1
        sentence = str(i) + '\t' + target + '\t' + text
        # print(sentence)
        rowTxt.append(sentence)

    random.shuffle(rowTxt)
    with open('Z-stance-ext.txt', 'w', encoding='utf_8_sig') as f:
        # 文件头部
        f.write('ID	TARGET	TEXT	STANCE')
        f.write('\n')

        for j in range(len(rowTxt)):
            f.write(rowTxt[j])
            f.write('\n')



if __name__ == '__main__':
    """
    input: Raw data
    output: Clean data
    """
    # cleanDataByTXT('./SC-dataset-zh.txt', './SC-dataset-zh-cleaned.txt')
    cleanDataByDF_NOLABEL('Z-stance-ext.csv')



