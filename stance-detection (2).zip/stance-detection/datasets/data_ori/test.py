import json
import os

maxlen = 512
modelPath = os.path.dirname(os.path.realpath(__file__))


def txt2jsonByWEIBO():
    f = modelPath + '/weibo-merge.txt'
    with open(f, 'r', encoding='utf-8') as train:  # 打开txt文件
        for line in train:
            line = line.replace('\n', '').replace('\r', '')
            d = {}
            # print(line)
            d['text'] = line.split("\t")[2]
            d['target'] = line.split("\t")[1].replace(' ', '').lower().replace('在', '').replace('的', '')

            with open(modelPath + '/weibo_target.json', 'a', encoding='utf-8') as file:  # 创建一个json文件，mode设置为'a'
                json.dump(d, file,
                          ensure_ascii=False)  # 将字典d写入json文件中，并设置ensure_ascii = False,主要是因为汉字是ascii字符码,
                # 若不指定该参数，那么文字格式就会是ascii码
                file.write('\n')

def txt2jsonByZ_stance():
    f = modelPath + '/Z-stance-ext.txt'
    with open(f, 'r', encoding='utf-8') as train:  # 打开txt文件
        for line in train:
            line = line.replace('\n', '').replace('\r', '')
            d = {}
            # print(line)
            d['text'] = line.split("\t")[2]
            d['target'] = line.split("\t")[1]

            with open(modelPath + '/Z-stance-ext.json', 'a', encoding='utf-8') as file:  # 创建一个json文件，mode设置为'a'
                json.dump(d, file,
                          ensure_ascii=False)  # 将字典d写入json文件中，并设置ensure_ascii = False,主要是因为汉字是ascii字符码,
                # 若不指定该参数，那么文字格式就会是ascii码
                file.write('\n')



def corpus():
    """语料生成器
    """
    while True:
        f = modelPath + '/Z-stance-ext.json'
        with open(f) as f:
            for l in f:
                l = json.loads(l)
                for text in text_process(l['text']):
                    print(text)
                    print(len(text))



def text_process(text):
    """分割文本
    """
    texts = text_segmentate(text, 32, u'\n。')
    result, length = '', 0
    for text in texts:
        if result and len(result) + len(text) > maxlen * 1.3:
            yield result
            result, length = '', 0
        result += text
    if result:
        yield result


def text_segmentate(text, maxlen, seps='\n', strips=None):
    """将文本按照标点符号划分为若干个短句
    """
    text = text.strip().strip(strips)
    if seps and len(text) > maxlen:
        pieces = text.split(seps[0])
        text, texts = '', []
        for i, p in enumerate(pieces):
            if text and p and len(text) + len(p) > maxlen - 1:
                texts.extend(text_segmentate(text, maxlen, seps[1:], strips))
                text = ''
            if i + 1 == len(pieces):
                text = text + p
            else:
                text = text + p + seps[0]
        if text:
            texts.extend(text_segmentate(text, maxlen, seps[1:], strips))
        return texts
    else:
        return [text]

corpus()
# txt2jsonByZ_stance()

