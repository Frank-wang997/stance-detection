#!/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：stance-detection 
@File    ：preproces.py
@IDE     ：PyCharm 
@Author  ：Sen Wang
@Date    ：2024/11/27 22:30 
'''

import pandas as pd

# 读取数据
def preprocess_data(file_path):
    data = []
    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f.readlines()[1:]:  # 跳过表头
            parts = line.strip().split("\t")
            target, text = parts[1], parts[2]
            formatted_text = f"以下是一条用户针对‘{target}的评论。请判断这条评论的立场是“反对”、“中立”还是“支持”：评论：{text}你的回答只需写“反对”、“中立”或“支持”。"
            data.append((formatted_text,))
    return pd.DataFrame(data, columns=["formatted_text"])

# 文件路径
test_file_path = 'weibo-test.txt'

# 处理数据
test_data = preprocess_data(test_file_path)

# 输出预处理后的数据
output_file_path = 'weibo-test-preprocessed.txt'
test_data.to_csv(output_file_path, sep="\t", index=False, header=False, encoding='utf-8')


