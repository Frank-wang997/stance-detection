#!/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：stance-detection 
@File    ：GPT-process.py
@IDE     ：PyCharm 
@Author  ：Sen Wang
@Date    ：2024/11/27 21:57 
'''


import pandas as pd
from sklearn import metrics
from sklearn.metrics import f1_score

def eval_each_target(y_trues, y_preds):
    # print(len(y_trues))
    # print(len(y_preds))
    y_trues = y_trues[:1000]
    y_preds = y_preds[:1000]
    target_list = ['CJ_T2', 'SE_T1', 'FK_T3', 'ET_T4', 'SZ_T5']
    count = 0
    for i in range(0, len(y_trues), 200):
        f1_mac = metrics.f1_score(y_trues[i:i+200], y_preds[i:i+200], labels=[0, 2], average='macro')
        print('{}:'.format(target_list[count]))
        print(u'val_f1: %.4f\n' % (f1_mac))
        count = count + 1

# 文件路径
true_labels_file = 'weibo-test_ans.txt'
predicted_labels_file = 'weibo-test-predictions-1208.txt'

# 加载真实标签
true_data = pd.read_csv(true_labels_file, sep="\t", header=0, names=["ID", "TARGET", "TEXT", "STANCE"])

# 加载预测标签
predicted_data = pd.read_csv(predicted_labels_file, sep="\t", header=0, names=["TARGET", "TEXT", "PROMPT", "PREDICTION"])

# 将标签映射为数字
label_mapping = {"AGAINST": 0, "NONE": 1, "FAVOR": 2}
label_mapping_ch = {"反对": 0, "中立": 1, "支持": 2}

true_data["STANCE"] = true_data["STANCE"].map(label_mapping)
predicted_data["STANCE"] = predicted_data["PREDICTION"].map(label_mapping_ch)

# 合并真实和预测数据，确保对齐
merged_data = pd.merge(true_data, predicted_data, on="TEXT", suffixes=("_true", "_pred"))

# 提取真实和预测标签
y_true = merged_data["STANCE_true"]
y_pred = merged_data["STANCE_pred"]
eval_each_target(y_true, y_pred)
# 计算 F1-score 的 macro 平均值，仅针对标签 0 和 2
f1_macro = f1_score(y_true, y_pred, labels=[0, 2], average="macro")
f1_mic = f1_score(y_true, y_pred, labels=[0, 2], average='micro')
print(f"F1 Macro Score (labels 0 and 2): {f1_macro}")
print(f"F1 Micro Score (labels 0 and 2): {f1_mic}")

