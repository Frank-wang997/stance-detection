#!/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：stance-detection 
@File    ：chatgpt-predict.py
@IDE     ：PyCharm 
@Author  ：Sen Wang
@Date    ：2024/11/28 23:13 
'''
import pandas as pd
import openai

# 设置 OpenAI API 密钥
openai.api_key = ""

# 读取测试文件
def read_data(file_path):
    data = []
    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f.readlines()[1:]:  # 跳过表头
            parts = line.strip().split("\t")
            target, text = parts[1], parts[2]
            data.append((target, text))
    return pd.DataFrame(data, columns=["TARGET", "TEXT"])

# 生成 prompt
def generate_prompt(row):
    return (f"以下是一条用户针对\"{row['TARGET']}\"的评论。请判断这条评论的立场是'反对'、'中立'还是'支持'。"
            f"评论：\"{row['TEXT']}\""
            f"你的回答只需写“反对”、“中立”或“支持”。")

# 调用 ChatGPT API 进行批量预测
def batch_predict(prompts):
    results = []
    for prompt in prompts:
        print(prompt)
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[{"role": "user", "content": prompt}]
        )
        results.append(response['choices'][0]['message']['content'].strip())

        print(f"results:{results}")
    return results

# 文件路径
test_file_path = 'weibo-test.txt'
output_file_path = 'weibo-test-predictions.txt'

# 加载数据
test_data = read_data(test_file_path)

# 生成 prompts
test_data["PROMPT"] = test_data.apply(generate_prompt, axis=1)

# 调用 API 进行预测
test_data["PREDICTION"] = batch_predict(test_data["PROMPT"].tolist())

# 保存结果
test_data.to_csv(output_file_path, sep="\t", index=False, encoding='utf-8')

print(f"预测完成，结果保存至 {output_file_path}")

