import random
import re
import pandas as pd
import sys
import os
import pathlib
import jieba

# 添加分词
keyWord_anti_china = ['自由门', '无界浏览', '法轮功', '法轮大法', '法轮佛法', 'falun gong', 'freegate', 'ultrasurf']
keyWord_vpn = ['vpn', '翻墙', '科学上网', 'GFW', 'shadowsocks', 'v2ray', 'ss', '机场', '梯子', '#ss', 'ssr']
keyWords = keyWord_anti_china + keyWord_vpn


def preprocess(sentence):
    tidyText = re.sub(r'(https|http)?:\/\/(\w|\.|\/|\?|\=|\&|\%)*\b', '', sentence, flags=re.MULTILINE)
    return tidyText

def txt2raw(df):
    i = 0
    sentence = ''
    stance = ''
    rowTxt = []
    for index, row in df.iterrows():
        df.sample(frac=1).reset_index(drop=True)
        if row['FAVOUR'] == 1:
            stance = 'FAVOR'
        elif row['AGAINST'] == 1:
            stance = 'AGAINST'
        elif row['NONE'] == 1:
            stance = 'NONE'
        i += 1
        sentence = str(i) + '\t法轮功\t' + preprocess(row['content']).strip() + '\t' + stance
        print(sentence)
        rowTxt.append(sentence)
    # random.shuffle(rowTxt)
    trainSet = int(len(rowTxt) * 0.9)
    devSet = int(len(rowTxt) * 0.1)
    with open('train-90%-raw.txt', 'w', encoding='utf_8_sig') as f:
        # 文件头部
        f.write('ID	TARGET	TEXT	STANCE')
        f.write('\n')

        for j in range(trainSet):
            f.write(rowTxt[j])
            f.write('\n')
    with open('dev-10%-raw.txt', 'w', encoding='utf_8_sig') as f:
        # 文件头部
        f.write('ID	TARGET	TEXT	STANCE')
        f.write('\n')

        for j in range(devSet):
            f.write(rowTxt[j + trainSet])
            f.write('\n')

def process():
    abs_path = pathlib.Path(__file__).parent.absolute()
    sys.path.append(sys.path.append(abs_path))
    from data_utils import write_samples, partition

    train_samples = set()
    dev_samples = set()
    # Read text file
    train_file_path = os.path.join(abs_path, 'train-90%-raw.txt')
    dev_file_path = os.path.join(abs_path, 'dev-10%-raw.txt')
    # process train file
    with open(train_file_path, 'r', encoding='utf8') as train:
        for line in train:
            if len(line.split("\t")) != 4: continue
            line = line.replace('\n', '').replace('\r', '')
            target = ' '.join(list(jieba.cut(line.split("\t")[1])))
            text = ' '.join(list(jieba.cut(line.split("\t")[2])))
            if line.split("\t")[3] == "FAVOR":
                stance = 1
            elif line.split("\t")[3] == "AGAINST":
                stance = -1
            else:
                stance = 0
            # stance = line.split("\t")[3]
            t_sample = text + '\n' + target + '\n' + str(stance)
            train_samples.add(t_sample)
    train_write_path = os.path.join(abs_path, '1-train.txt')
    write_samples(train_samples, train_write_path)

    # process test file
    with open(dev_file_path, 'r', encoding='utf8') as dev:
        for line in dev:
            if len(line.split("\t")) != 4: continue
            line = line.replace('\n', '').replace('\r', '')
            target = ' '.join(list(jieba.cut(line.split("\t")[1])))
            text = ' '.join(list(jieba.cut(line.split("\t")[2])))
            if line.split("\t")[3] == "FAVOR":
                stance = 1
            elif line.split("\t")[3] == "AGAINST":
                stance = -1
            else:
                stance = 0
            # stance = line.split("\t")[3]
            d_sample = text + '\n' + target + '\n' + str(stance)
            dev_samples.add(d_sample)
    dev_write_path = os.path.join(abs_path, '1-dev.txt')
    write_samples(dev_samples, dev_write_path)

def removeStopWords(In,Out):
    for word1 in keyWords:
        jieba.add_word(word1)
    fin = open(In, 'r', encoding='utf-8')
    lines = fin.readlines()
    fin.close()

    for i in range(0, len(lines), 3):
        lines[i] = lines[i].replace('\n', '')
        new_line = ""
        for w in lines[i].split(' '):
            if w not in stopwords:
                new_line += w + ' '
        new_line += '\n'
        lines[i] = new_line

    with open(Out, 'w', encoding='utf-8') as file:
        for line in lines:
            file.write(line)

if __name__ == '__main__':
    # stopwords file
    f_stopwords = open('weibo_stopwords.txt', 'r', encoding='utf-8')
    sw = f_stopwords.readlines()
    f_stopwords.close()

    stopwords = []
    for line in sw:
        line = line.replace('\n', '')
        stopwords.append(line)

    df = pd.read_csv('final.csv')
    txt2raw(df)
    process()

    # train file or dev file
    removeStopWords('train-90%-seg.txt', '1-train.txt')
    removeStopWords('dev-10%-seg.txt', '1-dev.txt')



