import random
import re
import pandas as pd
from pandas import DataFrame

from sklearn.utils import shuffle
SEED = 1
random.seed(SEED)

def preprocess(sentence):
    tidyText = re.sub(r'(https|http)?:\/\/(\w|\.|\/|\?|\=|\&|\%)*\b', '', sentence, flags=re.MULTILINE)
    return tidyText

if __name__ == '__main__':
    df = pd.read_csv('final.csv')
    i = 0
    sentence = ''
    stance = ''
    rowTxt = []
    stanceList = []
    df = shuffle(df)

    for index, row in df.iterrows():
        if row['FAVOUR'] == 1:
            stance = 2
        elif row['AGAINST'] == 1:
            stance = 0
        elif row['NONE'] == 1:
            stance = 1
        sentence = preprocess(row['content']).strip()
        rowTxt.append(sentence)
        stanceList.append(stance)

    data = {
        'content': rowTxt,
        'label' : stanceList
    }
    df1 = DataFrame(data)
    print(df1)
    df1.to_csv('flg.csv', encoding="utf_8_sig")

