# -*- coding: utf-8 -*-
# file: BERT_SPC.py
# author: songyouwei <youwei0314@gmail.com>
# Copyright (C) 2019. All Rights Reserved.
import torch
import torch.nn as nn


class XLNET_SPC(nn.Module):
    def __init__(self, xlnet, opt):
        super(XLNET_SPC, self).__init__()
        self.xlnet = xlnet
        self.dropout = nn.Dropout(opt.dropout)
        self.dense1 = nn.Linear(opt.bert_dim, 1)
        self.dense2 = nn.Linear(128, opt.polarities_dim)


    def forward(self, inputs):
        text_bert_indices, bert_segments_ids = inputs[0], inputs[1]
        # print("text维度:{}".format(text_bert_indices.shape))
        # print("bert_segments_ids维度:{}".format(bert_segments_ids.shape))
        output, pooled_output = self.xlnet(text_bert_indices, token_type_ids=bert_segments_ids) # tensor(64,128,768) tensor[(128,64,768),(128,64,768)]
        output = self.dropout(output)
        # print("dropout层输出维度:{}".format(pooled_output.shape))
        output = self.dense1(output)
        output = output.squeeze()
        logits = self.dense2(output)
        # print("logits:{}".format(logits.shape))

        return logits
