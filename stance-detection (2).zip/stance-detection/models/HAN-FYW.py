#!/usr/bin/python
# -*- coding: utf-8 -*-

import tensorflow as tf
from tensorflow.nn import rnn_cell


class HANConfig(object):
    """RNN配置参数"""

    # 模型参数
    embedding_dim = 300  # 词向量维度
    vocab_size = 5000  # 词汇表大小

    max_words_num = 50  # 每句话最大字数
    max_sentences_num = 25  # 最大句子数目
    num_classes = 4  # 类别数

    cell_type = 'lstm'
    hidden_size = 128

    keep_prob = 1  # dropout保留比例
    learning_rate = 1e-4  # 学习率
    lr_decay = 1  # learning rate decay
    l2_alpha = 0  # l2 loss
    clip = 5.0  # gradient clipping threshold

    batch_size = 32  # 每批训练大小
    num_epochs = 1000  # 总迭代轮次
    require_improvement = 500  # 1000轮未提升则停止

    print_per_batch = 5  # 每多少轮输出一次结果
    save_per_batch = 10  # 每多少轮存入tensorboard

    def to_string(self):
        return "max_words_num: " + str(self.max_words_num) + "\n" + "max_sentences_num: " + str(self.max_sentences_num) + "\n" + \
               "num_classes: " + str(self.num_classes) + '\n' + "keep_prob: " + str(self.keep_prob) + "\n" + \
               "embedding_dim: " + str(self.embedding_dim) + "\n" + "vocab_size: " + str(self.vocab_size) + '\n' + \
               "cell_type: " + str(self.cell_type) + "\n" + "hidden_size: " + str(self.hidden_size) + '\n' + \
               "learning_rate: " + str(self.learning_rate) + "\n" + "lr_decay: " + str(self.lr_decay) + "\n" + \
               "batch_size: " + str(self.batch_size) + "\n" + "num_epochs: " + str(self.num_epochs) + "\n" + \
               "l2_alpha: " + str(self.l2_alpha) + "\n" + "clip: " + str(self.clip) + "\n"


class HAN:
    def __init__(self, cfg, embedding_matrix):
        self.config = cfg

        # Placeholders for input, output and dropout
        # x的shape为[batch_size, 句子数， 句子长度(单词个数)]，但是每个样本的数据都不一样，，所以这里指定为空
        # y的shape为[batch_size, num_classes]
        self.input_x = tf.placeholder(tf.int32, shape=[None, None, None], name='input_x')
        self.input_y = tf.placeholder(tf.float32, shape=[None, self.config.num_classes], name='input_y')
        self.keep_prob = tf.placeholder(tf.float32, name='keep_prob')
        self.global_step = tf.Variable(0, trainable=False, name='global_step')
        self.embedding_matrix = embedding_matrix

        print("input_x: ", self.input_x.shape)
        print("input_y: ", self.input_y.shape)

        self.han()

    def han(self):
        # Keeping track of l2 regularization loss (optional)
        l2_loss = tf.constant(0.0)

        # Embedding layer
        with tf.device('/cpu:0'), tf.name_scope("embedding"):
            # # 字嵌入层
            # W = tf.Variable(
            #     tf.random_uniform([self.config.vocab_size + 1, self.config.embedding_dim], -1.0, 1.0),
            #     name="W")
            # embedding_inputs = tf.nn.embedding_lookup(W, self.input_x)

            # Word2Vec 词嵌入层
            embedding_inputs = tf.nn.embedding_lookup(self.embedding_matrix, self.input_x)
            print("embedding: ", embedding_inputs.shape)

        # Recurrent Neural Network
        with tf.name_scope("sent2vec"):
            # 单词注意力
            # GRU的输入tensor是[batch_size, max_time, ...].在构造句子向量时max_time应该是每个句子的长度，所以这里将
            # batch_size * sent_in_doc当做是batch_size.这样一来，每次输入一个句子，每个GRU的cell处理的都是一个单词的词向量
            # 并最终将一句话中的所有单词的词向量融合（Attention）在一起形成句子向量

            # shape为[batch_size*sent_in_doc, word_in_sent, embedding_dim]
            word_embedded = tf.reshape(embedding_inputs, [-1, self.config.max_words_num, self.config.embedding_dim])
            print("word_embedded: ", word_embedded.shape)
            # shape为[batch_size*sent_in_doc, word_in_sent, hidden_size*2]
            word_encoded = self.BidirectionalEncoder(word_embedded, name='word_encoder')
            print("word_encoded: ", word_encoded.shape)
            # shape为[batch_size*sent_in_doc, hidden_size*2]
            sent_vec = self.AttentionLayer(word_encoded, name='word_attention')
            print("sent_vec: ", sent_vec.shape)

        with tf.name_scope("doc2vec"):
            # 句子注意力
            sent_vec = tf.reshape(sent_vec, [-1, self.config.max_sentences_num, self.config.hidden_size * 2])
            print("sent_vec: ", sent_vec.shape)
            # shape为[batch_size, sent_in_doc, hidden_size*2]
            doc_encoded = self.BidirectionalEncoder(sent_vec, name='sent_encoder')
            print("doc_encoded: ", doc_encoded.shape)
            # shape为[batch_size, hidden_size*2]
            doc_vec = self.AttentionLayer(doc_encoded, name='sent_attention')
            print("doc_vec: ", doc_vec.shape)

        # Final scores and predictions
        with tf.name_scope("output"):
            W = tf.get_variable("W", shape=[self.config.hidden_size * 2, self.config.num_classes],
                                initializer=tf.contrib.layers.xavier_initializer())
            b = tf.Variable(tf.constant(0.1, shape=[self.config.num_classes]), name="b")
            l2_loss += tf.nn.l2_loss(W)
            l2_loss += tf.nn.l2_loss(b)
            self.logits = tf.nn.xw_plus_b(doc_vec, W, b, name="logits")
            print("logits: ", self.logits.shape)
            self.predictions = tf.argmax(self.logits, 1, name="predictions")
            print("predictions: ", self.predictions.shape)

        # Calculate mean cross-entropy loss
        with tf.name_scope("loss"):
            losses = tf.nn.softmax_cross_entropy_with_logits(logits=self.logits, labels=self.input_y)
            self.loss = tf.reduce_mean(losses) + self.config.l2_alpha * l2_loss

        # Create optimizer
        with tf.name_scope('optimization'):
            optimizer = tf.train.AdamOptimizer(self.config.learning_rate)
            gradients, variables = zip(*optimizer.compute_gradients(self.loss))
            gradients, _ = tf.clip_by_global_norm(gradients, self.config.clip)
            self.optim = optimizer.apply_gradients(zip(gradients, variables), global_step=self.global_step)

        # Accuracy
        with tf.name_scope("accuracy"):
            correct_predictions = tf.equal(self.predictions, tf.argmax(self.input_y, axis=1))
            self.acc = tf.reduce_mean(tf.cast(correct_predictions, tf.float32), name="accuracy")

    def BidirectionalEncoder(self, inputs, name):
        # 输入inputs的shape是[batch_size, max_time, embedding_dim] = [batch_size*sent_in_doc, word_in_sent, embedding_dim]
        with tf.variable_scope(name):
            cell_fw = get_cell(self.config.hidden_size, self.config.cell_type)
            cell_bw = get_cell(self.config.hidden_size, self.config.cell_type)
            # fw_outputs和bw_outputs的size都是[batch_size, max_time, hidden_size]
            ((fw_outputs, bw_outputs), (_, _)) = tf.nn.bidirectional_dynamic_rnn(cell_fw=cell_fw,
                                                                                 cell_bw=cell_bw,
                                                                                 inputs=inputs,
                                                                                 sequence_length=length(inputs),
                                                                                 dtype=tf.float32)
            # outputs的size是[batch_size, max_time, hidden_size*2]
            outputs = tf.concat((fw_outputs, bw_outputs), 2)
            return outputs

    def AttentionLayer(self, inputs, name):
        # inputs是GRU的输出，size是[batch_size, max_time, encoder_size(hidden_size * 2)]
        with tf.variable_scope(name):
            # u_context是上下文的重要性向量，用于区分不同单词/句子对于句子/文档的重要程度,
            # 因为使用双向GRU，所以其长度为2×hidden_size
            u_context = tf.Variable(tf.truncated_normal([self.config.hidden_size * 2]), name='u_context')
            # 使用一个全连接层编码GRU的输出的到期隐层表示,输出u的size是[batch_size, max_time, hidden_size * 2]
            h = tf.layers.dense(inputs, self.config.hidden_size * 2, activation=tf.nn.tanh)
            # shape为[batch_size, max_time, 1]
            alpha = tf.nn.softmax(tf.reduce_sum(tf.multiply(h, u_context), axis=2, keep_dims=True), dim=1)
            # reduce_sum之前shape为[batch_size, max_time, hidden_size*2]，之后shape为[batch_size, hidden_size*2]
            att_output = tf.reduce_sum(tf.multiply(inputs, alpha), axis=1)
            return att_output


def get_cell(hidden_size, cell_type):
    if cell_type == "vanilla":
        return rnn_cell.BasicRNNCell(hidden_size)
    elif cell_type == "lstm":
        return rnn_cell.BasicLSTMCell(hidden_size)
    elif cell_type == "gru":
        return rnn_cell.GRUCell(hidden_size)
    else:
        print("ERROR: '" + cell_type + "' is a wrong cell type !!!")
        return None


def length(sequences):
    # 返回序列中每一个元素的长度
    # # 输入inputs的shape是[batch_size, max_time, embedding_dim] = [batch_size*sent_in_doc, word_in_sent, embedding_dim]
    used = tf.sign(tf.reduce_max(tf.abs(sequences), reduction_indices=2))
    seq_len = tf.reduce_sum(used, reduction_indices=1)
    return tf.cast(seq_len, tf.int32)


if __name__ == '__main__':
    config = HANConfig
    from myModel.stance.preprocess import get_tokenizer, get_word2vec_embedding

    model = HAN(config, get_word2vec_embedding(get_tokenizer()))
