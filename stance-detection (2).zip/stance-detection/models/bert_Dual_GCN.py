# -*- coding: utf-8 -*-
# file: BERT_SPC.py
# author: songyouwei <youwei0314@gmail.com>
# Copyright (C) 2019. All Rights Reserved.
import copy
import math

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np


class LayerNorm(nn.Module):
    "Construct a layernorm module (See citation for details)."

    def __init__(self, features, eps=1e-6):
        super(LayerNorm, self).__init__()
        self.a_2 = nn.Parameter(torch.ones(features))
        self.b_2 = nn.Parameter(torch.zeros(features))
        self.eps = eps

    def forward(self, x):
        mean = x.mean(-1, keepdim=True)
        std = x.std(-1, keepdim=True)
        return self.a_2 * (x - mean) / (std + self.eps) + self.b_2


class GraphConvolution(nn.Module):
    """
    Simple GCN layer, similar to https://arxiv.org/abs/1609.02907
    """
    def __init__(self, in_features, out_features, bias=True):
        super(GraphConvolution, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.weight = nn.Parameter(torch.FloatTensor(in_features, out_features))
        if bias:
            self.bias = nn.Parameter(torch.FloatTensor(out_features))
        else:
            self.register_parameter('bias', None)

    def forward(self, text, adj):


        hidden = torch.matmul(text, self.weight)  # hidden:torch.Size([16, 128, 600])
        denom = torch.sum(adj, dim=2, keepdim=True) + 1  # denom:torch.Size([16, 128, 1])

        # torch.matmul(adj, hidden):torch.Size([16, 128, 600])
        output = torch.matmul(adj, hidden) / denom  # output:torch.Size([16, 128, 600])


        if self.bias is not None:
            return output + self.bias
        else:
            return output

class GELU(nn.Module):
    def __init__(self):
        super(GELU, self).__init__()

    def forward(self, x):
        return 0.5*x*(1+F.tanh(np.sqrt(2/np.pi)*(x+0.044715*torch.pow(x,3))))


def clones(module, N):
    return nn.ModuleList([copy.deepcopy(module) for _ in range(N)])


def attention(query, key, mask=None, dropout=None):
    d_k = query.size(-1)
    scores = torch.matmul(query, key.transpose(-2, -1)) / math.sqrt(d_k)
    if mask is not None:
        scores = scores.masked_fill(mask == 0, -1e9)

    p_attn = F.softmax(scores, dim=-1)
    if dropout is not None:
        p_attn = dropout(p_attn)

    return p_attn


class MultiHeadAttention(nn.Module):

    def __init__(self, h, d_model, dropout=0.1):
        super(MultiHeadAttention, self).__init__()
        assert d_model % h == 0
        self.d_k = d_model // h
        self.h = h
        self.linears = clones(nn.Linear(d_model, d_model), 2)
        self.dropout = nn.Dropout(p=dropout)

    def forward(self, query, key, mask=None):
        mask = mask[:, :, :query.size(1)]
        if mask is not None:
            mask = mask.unsqueeze(1)

        nbatches = query.size(0)
        query, key = [l(x).view(nbatches, -1, self.h, self.d_k).transpose(1, 2)
                      for l, x in zip(self.linears, (query, key))]

        attn = attention(query, key, mask=mask, dropout=self.dropout)
        return attn


class BERT_GCN(nn.Module):
    def __init__(self, bert, opt):
        super(BERT_GCN, self).__init__()
        self.bert = bert
        self.opt = opt
        self.bert_dropout = nn.Dropout(opt.dropout)
        self.layernorm = LayerNorm(opt.bert_dim)
        self.gcn1 = GraphConvolution(opt.bert_dim, opt.bert_dim)
        self.gcn2 = GraphConvolution(opt.bert_dim, opt.bert_dim)
        self.gcn3 = GraphConvolution(opt.bert_dim, opt.bert_dim)
        self.layers = 2
        self.bert_dim = opt.bert_dim
        self.mem_dim = opt.bert_dim // 2
        self.attention_heads = opt.attention_heads
        self.pooled_drop = nn.Dropout(opt.dropout)
        self.affine1 = nn.Parameter(torch.Tensor(self.mem_dim, self.mem_dim))
        self.affine2 = nn.Parameter(torch.Tensor(self.mem_dim, self.mem_dim))
        self.gcn_drop = nn.Dropout(opt.gcn_dropout)
        self.classifier1 = nn.Linear(opt.bert_dim * 2, 128)
        self.classifier2 = nn.Linear(128, opt.polarities_dim)


        # gcn layer
        self.W = nn.ModuleList()
        for layer in range(self.layers):
            input_dim = self.bert_dim if layer == 0 else self.mem_dim
            self.W.append(nn.Linear(input_dim, self.mem_dim))

        self.attn = MultiHeadAttention(opt.attention_heads, self.bert_dim)
        self.weight_list = nn.ModuleList()
        for j in range(self.layers):
            input_dim = self.bert_dim if j == 0 else self.mem_dim
            self.weight_list.append(nn.Linear(input_dim, self.mem_dim))

        self.dense1 = nn.Linear(opt.bert_dim, 128)
        self.dense2 = nn.Linear(128, opt.polarities_dim)
        self.gelu = GELU()


    def forward(self, inputs):
        text_bert_indices, attention_mask, bert_segments_ids, adj, src_mask, text_raw_indices, attention_raw_mask = inputs[0], inputs[1], inputs[2], inputs[3], inputs[4], inputs[5], inputs[6]
        src_mask = src_mask.unsqueeze(-2)

        word_output, pooled_rat_output = self.bert(text_raw_indices, attention_mask=attention_raw_mask)
        sequence_output = self.layernorm(word_output)
        gcn_inputs = self.bert_dropout(sequence_output)

        other, pooled_output = self.bert(text_bert_indices, attention_mask=attention_mask,
                                               token_type_ids=bert_segments_ids)
        pooled_output = self.pooled_drop(pooled_output)

        denom_dep = adj.sum(2).unsqueeze(2) + 1
        attn_tensor = self.attn(gcn_inputs, gcn_inputs, src_mask)
        attn_adj_list = [attn_adj.squeeze(1) for attn_adj in torch.split(attn_tensor, 1, dim=1)]
        multi_head_list = []
        outputs_dep = None
        adj_ag = None

        # * Average Multi-head Attention matrixes
        for i in range(self.attention_heads):
            if adj_ag is None:
                adj_ag = attn_adj_list[i]
            else:
                adj_ag += attn_adj_list[i]
        adj_ag /= self.attention_heads

        for j in range(adj_ag.size(0)):
            adj_ag[j] -= torch.diag(torch.diag(adj_ag[j]))
            adj_ag[j] += torch.eye(adj_ag[j].size(0)).cuda(2)
        adj_ag = src_mask.transpose(1, 2) * adj_ag

        denom_ag = adj_ag.sum(2).unsqueeze(2) + 1
        outputs_ag = word_output
        outputs_dep = word_output

        for l in range(self.layers):
            # ************SynGCN*************
            Ax_dep = adj.bmm(outputs_dep)
            AxW_dep = self.W[l](Ax_dep)
            AxW_dep = AxW_dep / denom_dep
            gAxW_dep = F.relu(AxW_dep)

            # ************SemGCN*************
            Ax_ag = adj_ag.bmm(outputs_ag)
            AxW_ag = self.weight_list[l](Ax_ag)
            AxW_ag = AxW_ag / denom_ag
            gAxW_ag = F.relu(AxW_ag)

            # * mutual Biaffine module
            A1 = F.softmax(torch.bmm(torch.matmul(gAxW_dep, self.affine1), torch.transpose(gAxW_ag, 1, 2)), dim=-1)
            A2 = F.softmax(torch.bmm(torch.matmul(gAxW_ag, self.affine2), torch.transpose(gAxW_dep, 1, 2)), dim=-1)
            gAxW_dep, gAxW_ag = torch.bmm(A1, gAxW_ag), torch.bmm(A2, gAxW_dep)
            outputs_dep = self.gcn_drop(gAxW_dep) if l < self.layers - 1 else gAxW_dep
            outputs_ag = self.gcn_drop(gAxW_ag) if l < self.layers - 1 else gAxW_ag


        # avg pooling asp feature
        aspect_mask = torch.ones((1, 128)).cuda(2)
        asp_wn = aspect_mask.sum(dim=1).unsqueeze(-1)
        aspect_mask = aspect_mask.unsqueeze(-1).repeat(1, 1, self.opt.bert_dim // 2)
        outputs1 = (outputs_ag * aspect_mask).sum(dim=1) / asp_wn
        outputs2 = (outputs_dep * aspect_mask).sum(dim=1) / asp_wn
        # outputs = torch.cat((outputs1, outputs2), dim=1)
        # print("outputs1:{}".format(outputs1.size()))
        # print("outputs2:{}".format(outputs2.size()))
        # output = self.dense1(outputs)
        # logits = self.dense2(output)
        # # logits = self.gelu(logits)
        # return logits
        final_outputs = torch.cat((outputs1, outputs2, pooled_output), dim=-1)
        logits = self.classifier1(final_outputs)
        logits = self.classifier2(logits)
        return logits



class DualGCNBertClassifier(nn.Module):
    def __init__(self, bert, opt):
        super().__init__()
        self.opt = opt
        self.gcn_model = BERT_GCN(bert, opt=opt)
        self.classifier = nn.Linear(opt.bert_dim * 2, opt.polarities_dim)

    def forward(self, inputs):
        outputs1, outputs2, adj_ag, adj_dep, pooled_output = self.gcn_model(inputs)
        final_outputs = torch.cat((outputs1, outputs2, pooled_output), dim=-1)
        logits = self.classifier(final_outputs)


        return logits

