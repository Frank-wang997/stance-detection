# -*- coding: utf-8 -*-
# file: BERT_SPC.py
# author: songyouwei <youwei0314@gmail.com>
# Copyright (C) 2019. All Rights Reserved.
import torch
import torch.nn as nn
from nltk import Variable
from layers.attention import Attention, NoQueryAttention


class BERT_LSTM(nn.Module):
    def __init__(self, bert, opt):
        super(BERT_LSTM, self).__init__()

        self.opt = opt
        self.bert = bert
        self.lstm = nn.LSTM(opt.bert_dim, opt.hidden_dim, num_layers=2, bidirectional=True, batch_first=True)
        self.dropout1 = nn.Dropout(opt.dropout)
        self.dropout2 = nn.Dropout(opt.dropout)


        self.dense1 = nn.Linear(opt.bert_dim, 128)
        self.dense2 = nn.Linear(128, opt.polarities_dim)
        self.fc = nn.Linear(opt.hidden_dim, opt.polarities_dim)
        self.fc_1 = nn.Linear(opt.bert_dim, opt.hidden_dim)



    def forward(self, inputs):
        text_bert_indices, bert_segments_ids, feature__bert_indices = inputs[0], inputs[1], inputs[2] # text维度:torch.Size([64, 128])

        word_output, pooled_output = self.bert(text_bert_indices, token_type_ids=bert_segments_ids) # pooled_output:torch.Size([64, 768]) word_output:torch.Size([64, 128, 768])
        _, feature = self.bert(feature__bert_indices)
        word_output = self.dropout1(word_output)

        h_init = torch.randn(4, word_output.size(0), self.opt.hidden_dim).to(self.opt.device)  # 构建h输入参数
        c_init = torch.randn(4, word_output.size(0), self.opt.hidden_dim).to(self.opt.device)

        h, (h_n, c_n) = self.lstm(word_output, (h_init, c_init)) # h_n输出维度:torch.Size([4, 64, 300]) h:torch.Size([64, 128, 600])
        h_out = h_n[0]


        logits = self.fc(h_out) # logits输出维度:torch.Size([64, 3])
        # print("logits输出维度:{}".format(logits.shape))
        return logits
