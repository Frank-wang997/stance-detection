from layers.dynamic_rnn import DynamicLSTM
import torch
import torch.nn as nn
import torch.nn.functional as F

class GraphConvolution(nn.Module):
    """
    Simple GCN layer, similar to https://arxiv.org/abs/1609.02907
    """
    def __init__(self, in_features, out_features, bias=True):
        super(GraphConvolution, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.weight = nn.Parameter(torch.FloatTensor(in_features, out_features))
        if bias:
            self.bias = nn.Parameter(torch.FloatTensor(out_features))
        else:
            self.register_parameter('bias', None)

    def forward(self, text, adj):

        # text_out层输出维度: torch.Size([16, 128, 600])

        # adj层输出维度: torch.Size([16, 128, 128])
        hidden = torch.matmul(text, self.weight)  # hidden:torch.Size([16, 128, 600])
        denom = torch.sum(adj, dim=2, keepdim=True) + 1  # denom:torch.Size([16, 128, 1])
        # torch.matmul(adj, hidden):torch.Size([16, 128, 600])
        output = torch.matmul(adj, hidden) / denom  # output:torch.Size([16, 128, 600])


        if self.bias is not None:
            return output + self.bias
        else:
            return output


class LSTM_GCN(nn.Module):
    def __init__(self, embedding_matrix, opt):
        super(LSTM_GCN, self).__init__()
        self.opt = opt
        self.embed = nn.Embedding.from_pretrained(torch.tensor(embedding_matrix, dtype=torch.float))
        self.text_lstm = DynamicLSTM(opt.embed_dim, opt.hidden_dim, num_layers=1, batch_first=True, bidirectional=True)
        self.gcn1 = GraphConvolution(2*opt.hidden_dim, 2*opt.hidden_dim)
        self.gcn2 = GraphConvolution(2*opt.hidden_dim, 2*opt.hidden_dim)
        self.gcn3 = GraphConvolution(2*opt.hidden_dim, 2*opt.hidden_dim)


        self.fc = nn.Linear(2*opt.hidden_dim, opt.polarities_dim)
        self.dfc = nn.Linear(4*opt.hidden_dim, opt.polarities_dim)

        self.text_embed_dropout = nn.Dropout(0.3)

    def forward(self, inputs):
        text_indices, target_indices, adj = inputs

        text_len = torch.sum(text_indices != 0, dim=-1)
        target_len = torch.sum(target_indices != 0, dim=-1)
        text = self.embed(text_indices)
        text = self.text_embed_dropout(text)
        text_out, (_, _) = self.text_lstm(text, text_len) # text_out:torch.Size([16, 128, 600])


        x = F.relu(self.gcn1(text_out, adj)) # in_adj层输出维度:torch.Size([16, 128, 128])
        x = F.relu(self.gcn2(x, adj))  # cross_adj层输出维度:torch.Size([16, 128 128])
        x = F.relu(self.gcn3(x, adj))

        alpha_mat = torch.matmul(x, text_out.transpose(1, 2))
        alpha = F.softmax(alpha_mat.sum(1, keepdim=True), dim=2)
        x = torch.matmul(alpha, text_out).squeeze(1)  # batch_size x 2*hidden_dim


        output = self.fc(x)
        return output