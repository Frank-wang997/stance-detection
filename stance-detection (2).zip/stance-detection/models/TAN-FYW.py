#!/usr/bin/python
# -*- coding: utf-8 -*-

import tensorflow as tf
from tensorflow.nn import rnn_cell


class TANConfig(object):
    """TAN配置参数"""

    # 模型参数
    embedding_dim = 128  # 词向量维度
    vocab_size = 5000  # 词汇表大小
    sequence_length = 800  # 序列长度
    target_length = 10  # 主题长度
    num_classes = 4  # 类别数

    cell_type = 'lstm'
    hidden_dim = 128  # rnn cell

    hidden_size = 128  # dense

    keep_prob = 1  # dropout保留比例
    learning_rate = 1e-3  # 学习率
    lr_decay = 1  # learning rate decay
    l2_alpha = 0
    clip = 5.0  # gradient clipping threshold

    batch_size = 32  # 每批训练大小
    num_epochs = 1000  # 总迭代轮次
    require_improvement = 500  # 1000轮未提升则停止

    print_per_batch = 5  # 每多少轮输出一次结果
    save_per_batch = 10  # 每多少轮存入tensorboard

    def to_string(self):
        return "sequence_length: " + str(self.sequence_length) + "\n" + "num_classes: " + str(self.num_classes) + '\n' + \
               "embedding_size: " + str(self.embedding_dim) + "\n" + "vocab_size: " + str(self.vocab_size) + '\n' + \
               "cell_type: " + str(self.cell_type) + "\n" + "hidden_size: " + str(self.hidden_size) + '\n' + \
               "learning_rate: " + str(self.learning_rate) + "\n" + "keep_prob: " + str(self.keep_prob) + "\n" + \
               "batch_size: " + str(self.batch_size) + "\n" + "num_epochs: " + str(self.num_epochs) + "\n" + \
               "l2_alpha: " + str(self.l2_alpha) + "\n" + "clip: " + str(self.clip) + "\n"


class TAN:
    def __init__(self, cfg):
        self.config = cfg
        # Placeholders for input, output and dropout
        self.input_t = tf.placeholder(tf.int32, shape=[None, self.config.target_length], name='input_t')
        self.input_x = tf.placeholder(tf.int32, shape=[None, self.config.sequence_length], name='input_x')
        self.input_y = tf.placeholder(tf.float32, shape=[None, self.config.num_classes], name='input_y')
        self.keep_prob = tf.placeholder(tf.float32, name='keep_prob')
        self.global_step = tf.Variable(0, trainable=False, name='global_step')

        print("input_t: ", self.input_t.shape)
        print("input_x: ", self.input_x.shape)
        print("input_y: ", self.input_y.shape)

        # Keeping track of l2 regularization loss (optional)
        l2_loss = tf.constant(0.0)

        # Embedding layer
        with tf.device('/cpu:0'), tf.name_scope("text-embedding"):
            # 字嵌入层
            self.W = tf.Variable(
                tf.random_uniform([self.config.vocab_size + 1, self.config.embedding_dim], -1.0, 1.0),
                name="W")
            embedding_inputs = tf.nn.embedding_lookup(self.W, self.input_x)
            target_embedding = tf.nn.embedding_lookup(self.W, self.input_t)
            print("embedding_inputs: ", embedding_inputs.shape)
            print("target_embedding: ", target_embedding.shape)

        # Recurrent Neural Network
        with tf.name_scope("rnn"):
            input_x_encoded = self.BidirectionalEncoder(embedding_inputs, name="rnn_encode")
            print("input_x_encoded: ", input_x_encoded.shape)

        with tf.name_scope("tan"):
            t = tf.reduce_sum(target_embedding, axis=1)  # (batch_size, emb_dim)
            t = tf.divide(t, tf.reshape(length(self.input_t), [-1, 1]))  # (batch_size, emb_dim)
            t = tf.expand_dims(t, axis=1)  # (batch_size, 1, emb_dim)
            t = tf.tile(t, [1, self.config.sequence_length, 1])  # (batch_size, sequence_length, emb_dim)
            t = tf.concat([input_x_encoded, t], axis=2)  # (batch_size, sent_lenA, emb_dim * 2)
            print("t: ", t.shape)
            tan_encoded = self.AttentionLayer(t)  # (batch_size, sent_lenA, 1)
            print("tan_encoded: ", tan_encoded.shape)

        # Final scores and predictions
        with tf.name_scope("output"):
            W = tf.get_variable("W", shape=[self.config.hidden_size, self.config.num_classes],
                                initializer=tf.contrib.layers.xavier_initializer())
            b = tf.Variable(tf.constant(0.1, shape=[self.config.num_classes]), name="b")
            l2_loss += tf.nn.l2_loss(W)
            l2_loss += tf.nn.l2_loss(b)
            m = embedding_inputs * tan_encoded
            print("embedding_inputs * tan_encoded: ", m.shape)
            m = tf.reduce_mean(m, axis=1)
            print("reduced_mean: ", m.shape)
            self.logits = tf.nn.xw_plus_b(m, W, b, name="logits")
            print("logits: ", self.logits.shape)
            self.predictions = tf.argmax(self.logits, 1, name="predictions")
            print("predictions: ", self.predictions.shape)

        # Calculate mean cross-entropy loss
        with tf.name_scope("loss"):
            losses = tf.nn.softmax_cross_entropy_with_logits(logits=self.logits, labels=self.input_y)
            self.loss = tf.reduce_mean(losses) + self.config.l2_alpha * l2_loss

        # Create optimizer
        with tf.name_scope('optimization'):
            optimizer = tf.train.AdamOptimizer(self.config.learning_rate)
            gradients, variables = zip(*optimizer.compute_gradients(self.loss))
            gradients, _ = tf.clip_by_global_norm(gradients, self.config.clip)
            self.optim = optimizer.apply_gradients(zip(gradients, variables), global_step=self.global_step)

        # Accuracy
        with tf.name_scope("accuracy"):
            correct_predictions = tf.equal(self.predictions, tf.argmax(self.input_y, axis=1))
            self.acc = tf.reduce_mean(tf.cast(correct_predictions, tf.float32), name="accuracy")

    # 双向LSTM或GRU编码器
    def BidirectionalEncoder(self, inputs, name):
        # 输入inputs的shape是[batch_size, max_time, embedding_dim] = [batch_size*sent_in_doc, word_in_sent, embedding_dim]
        with tf.variable_scope(name):
            cell_fw = get_cell(self.config.hidden_dim, self.config.cell_type)
            cell_bw = get_cell(self.config.hidden_dim, self.config.cell_type)
            # fw_outputs和bw_outputs的size都是[batch_size, max_time, hidden_dim]
            ((fw_outputs, bw_outputs), (_, _)) = tf.nn.bidirectional_dynamic_rnn(cell_fw=cell_fw,
                                                                                 cell_bw=cell_bw,
                                                                                 inputs=inputs,
                                                                                 sequence_length=_length(inputs),
                                                                                 dtype=tf.float32)
            # outputs的size是[batch_size, max_time, hidden_dim*2]
            outputs = tf.concat((fw_outputs, bw_outputs), 2)
            return outputs

    # 注意力机制
    def AttentionLayer(self, sequence):
        # sequence shape: (batch_size, sent_len, emb_dim * 2)
        W = tf.get_variable('attention_weight', (self.config.embedding_dim + self.config.hidden_dim * 2, 1))
        b = tf.get_variable('attention_bias', (1,))

        def fn(sent):
            # sent shape: (sent_len, emb_dim * 2)
            return tf.matmul(sent, W) + b  # (sent_len, 1)

        # iterate each batch sentence
        return tf.nn.softmax(tf.map_fn(fn, sequence))  # (batch_size, sent_len, 1)


def get_cell(hidden_dim, cell_type):
    if cell_type == "vanilla":
        return rnn_cell.BasicRNNCell(hidden_dim)
    elif cell_type == "lstm":
        return rnn_cell.BasicLSTMCell(hidden_dim)
    elif cell_type == "gru":
        return rnn_cell.GRUCell(hidden_dim)
    else:
        print("ERROR: '" + cell_type + "' is a wrong cell type !!!")
        return None


def length(seq):
    relevant = tf.sign(tf.abs(seq))
    seq_len = tf.reduce_sum(relevant, reduction_indices=1)
    seq_len = tf.cast(seq_len, tf.float32)
    return seq_len


def _length(sequences):
    # 返回序列中每一个元素的长度
    # # 输入inputs的shape是[batch_size, max_time, embedding_dim] = [batch_size*sent_in_doc, word_in_sent, embedding_dim]
    used = tf.sign(tf.reduce_max(tf.abs(sequences), reduction_indices=2))
    seq_len = tf.reduce_sum(used, reduction_indices=1)
    return tf.cast(seq_len, tf.int32)


if __name__ == '__main__':
    config = TANConfig
    model = TAN(config)
