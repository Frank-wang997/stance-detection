# -*- coding: utf-8 -*-
# file: BERT_SPC.py
# author: songyouwei <youwei0314@gmail.com>
# Copyright (C) 2019. All Rights Reserved.
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np

class GELU(nn.Module):
    def __init__(self):
        super(GELU, self).__init__()

    def forward(self, x):
        return 0.5*x*(1+F.tanh(np.sqrt(2/np.pi)*(x+0.044715*torch.pow(x,3))))


class BERT_SPC(nn.Module):
    def __init__(self, bert, opt):
        super(BERT_SPC, self).__init__()
        self.bert = bert
        self.dense1 = nn.Linear(opt.bert_dim, 128)
        self.dense2 = nn.Linear(128, opt.polarities_dim)

        self.bert_dropout = nn.Dropout(opt.dropout)
        self.gelu = GELU()



    def forward(self, inputs):
        text_bert_indices, attention_mask, bert_segments_ids = inputs[0], inputs[1], inputs[2]

        other, pooled_output = self.bert(text_bert_indices, attention_mask=attention_mask, token_type_ids=bert_segments_ids, return_dict=False)

        # print("bert层pooled_output输出维度:{}".format(pooled_output.shape))
        # print("bert层other输出维度:{}".format(other.shape))


        pooled_output = self.bert_dropout(pooled_output)
        # print("dropout层输出维度:{}".format(pooled_output.shape))
        pooled_output = self.dense1(pooled_output)
        logits = self.dense2(pooled_output)
        # logits = self.gelu(logits)
        return logits


