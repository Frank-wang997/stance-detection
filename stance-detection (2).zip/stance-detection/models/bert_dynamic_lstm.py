# -*- coding: utf-8 -*-
# file: atae-lstm
# author: songyouwei <youwei0314@gmail.com>
# Copyright (C) 2018. All Rights Reserved.
from layers.attention import Attention, NoQueryAttention
from layers.dynamic_rnn import DynamicLSTM
import torch
import torch.nn as nn

from layers.squeeze_embedding import SqueezeEmbedding


class BERT_DYNAMIC_LSTM(nn.Module):
    def __init__(self, bert, opt):
        super(BERT_DYNAMIC_LSTM, self).__init__()
        self.opt = opt
        self.bert = bert
        self.squeeze_embedding = SqueezeEmbedding()
        self.lstm = DynamicLSTM(opt.bert_dim, opt.hidden_dim, num_layers=1, batch_first=True)
        self.attention = NoQueryAttention(opt.hidden_dim, score_function='bi_linear')
        self.dense = nn.Linear(opt.hidden_dim, opt.polarities_dim)
        self.dropout1 = nn.Dropout(opt.dropout)


    def forward(self, inputs):
        text_bert_indices, bert_segments_ids, text_raw_indices, aspect_indices = inputs[0], inputs[1], inputs[2], inputs[3]
        word_output, pooled_output = self.bert(text_bert_indices, token_type_ids=bert_segments_ids) #pooled_output:torch.Size([64, 768]) word_output:torch.Size([64, 128, 768])

        x_len = torch.sum(text_raw_indices != 0, dim=-1)
        # x_len_max = torch.max(x_len)
        # aspect_len = torch.tensor(torch.sum(aspect_indices != 0, dim=-1), dtype=torch.float).to(self.opt.device)
        word_output = self.dropout1(word_output)

        x = word_output # torch.Size([64, 128, 768])
        x = self.squeeze_embedding(x, x_len) # torch.Size([64, 128, 768])
        x = self.dropout1(x) # torch.Size([64, 128, 768])

        h, (_, _) = self.lstm(x, x_len) # torch.Size([64, 128, 300])

        _, score = self.attention(h)
        output = torch.squeeze(torch.bmm(score, h), dim=1) # torch.Size([64, 300])

        out = self.dense(output)
        return out
