# TAN
# Paper "Stance Classification with Target-Specific Neural Attention Networks"
# https://www.ijcai.org/Proceedings/2017/0557.pdf

import torch
from torch import nn
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence

from layers.dynamic_rnn import DynamicLSTM


class TAN(nn.Module):
    def __init__(self, embedding_matrix, opt):
        super(TAN, self).__init__()
        self.embed = nn.Embedding.from_pretrained(torch.tensor(embedding_matrix, dtype=torch.float))
        self.opt = opt
        self.model_name = 'TAN'
        self.dropout = nn.Dropout(opt.dropout)

        self.lstm = DynamicLSTM(opt.embed_dim, opt.hidden_dim, num_layers=1, batch_first=True, bidirectional=True)
        self.linear = nn.Linear(opt.hidden_dim * 2, 128)
        self.out = nn.Linear(128, 3)
        self.relu = nn.ReLU()

        self.W_h = nn.Parameter(torch.rand([1, 3], requires_grad=True))
        self.b_tanh = nn.Parameter(torch.rand([3], requires_grad=True))

    def forward(self, inputs):
        x, x_len, target_word = inputs[0], inputs[1], inputs[2]  # [batch_size, seq_len], [batch_size], [batch_size, seq_len]

        x = self.embed(x)  # [batch_size, seq_len, embedding_size]
        target_word = self.embed(target_word)  # [batch_size, seq_len, embedding_size]

        text_out, (_, _) = self.lstm(x, x_len)  # [batch_size, seq_len, hidden_dim*2]

        # Target-augmented
        target_word = torch.mean(target_word, dim=1)  # [batch_size, embedding_size]
        target_word = target_word.unsqueeze(dim=1)  # [batch_size, 1, embedding_size]
        target_word = target_word.repeat(1, text_out.shape[1], 1)  # [batch_size, seq_len, embedding_size]
        target_augment = torch.cat([text_out, target_word], dim=2)  # [batch_size, seq_len, embedding_size+hidden_dim*2]

        atten, alpha = self.Attention_Stance(text_out, x, self.W_h, self.b_tanh, x_len, target_augment)
        # atten = self.dropout(atten)

        linear = self.relu(self.linear(atten))
        linear = self.dropout(linear)
        out = self.out(linear)
        return out

    def Attention_Stance(self, hidden_unit, h_embedding2, W_h, b_tanh, length, target_augment):
        W_h = nn.Parameter(torch.rand([1, 3 * self.opt.hidden_dim, 1], requires_grad=True)).to(self.opt.device)
        b_tanh = nn.Parameter(torch.rand([1, 1, 1], requires_grad=True)).to(self.opt.device)
        s1 = target_augment.size(0)
        s2 = target_augment.size(1)
        W_h = W_h.repeat(s1, 1, 1)
        m1 = torch.bmm(target_augment, W_h)  # [batch_size, seq_len, 1]
        u = (m1 + b_tanh.repeat(s1, s2, 1)).squeeze(2)

        # for i in range(len(length)):
        #     u[i, length[i]:] = torch.Tensor([-1e6])

        alphas = nn.functional.softmax(u)
        context = torch.bmm(alphas[:, :hidden_unit.size(1)].unsqueeze(1), hidden_unit)
        context = context.squeeze(1)
        alphas = torch.unsqueeze(alphas, dim=2)
        return context, alphas
