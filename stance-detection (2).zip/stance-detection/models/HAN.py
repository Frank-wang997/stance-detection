import torch
from torch import nn
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence
import torch.nn.functional as F
from layers.dynamic_rnn import DynamicLSTM



class HAN(torch.nn.Module):
    def __init__(self, max_word_num, max_sents_num, vocab_size, hidden_size, num_classes, embedding_dim,
                 embedding_matrix=None, dropout_p=0.5):
        super(HAN, self).__init__()

        self.max_word_num = max_word_num  # 15 句子所含最大词数
        self.max_sents_num = max_sents_num  # 60 文档所含最大句子数

        self.embedding_dim = embedding_dim
        self.hidden_size = hidden_size
        self.num_classes = num_classes
        self.dropout_p = dropout_p

        self.embedding = torch.nn.Embedding(vocab_size, self.embedding_dim, padding_idx=pad_id)
        if embedding_matrix is not None:
            self.embedding.weight.data.copy_(torch.from_numpy(embedding_matrix))
            for p in self.embedding.parameters():
                p.requires_grad = False

        self.dropout0 = torch.nn.Dropout(dropout_p)

        # self.layernorm1 = torch.nn.LayerNorm(normalized_shape=(sent_maxlen, embedding_dim), eps=1e-6)
        # self.layernorm2 = torch.nn.LayerNorm(normalized_shape=2*hidden_size, eps=1e-6)

        self.bi_rnn1 = torch.nn.GRU(self.embedding_dim, self.hidden_size, bidirectional=True, batch_first=True,
                                    dropout=0.2)
        self.word_attn = torch.nn.Linear(self.hidden_size * 2, self.hidden_size)
        self.word_ctx = torch.nn.Linear(self.hidden_size, 1, bias=False)

        self.bi_rnn2 = torch.nn.GRU(2 * self.hidden_size, self.hidden_size, bidirectional=True, batch_first=True,
                                    dropout=0.2)
        self.sent_attn = torch.nn.Linear(self.hidden_size * 2, self.hidden_size)
        self.sent_ctx = torch.nn.Linear(self.hidden_size, 1, bias=False)

        self.dropout = torch.nn.Dropout(dropout_p)
        self.out = torch.nn.Linear(self.hidden_size * 2, self.num_classes)

    def forward(self, inputs, hidden1=None, hidden2=None):  # [b, 60, 15]
        embedded = self.dropout0(self.embedding(inputs))  # =>[b, 60, 15, 100]

        word_inputs = embedded.view(-1, embedded.size()[-2], embedded.size()[-1])  # =>[b*60, 15, embedding_dim]
        # word_inputs = self.layernorm1(word_inputs)
        self.bi_rnn1.flatten_parameters()
        """
        为了提高内存的利用率和效率，调用flatten_parameters让parameter的数据存放成contiguous chunk(连续的块)。
        类似我们调用tensor.contiguous
        """
        word_encoder_output, hidden1 = self.bi_rnn1(word_inputs,
                                                    hidden1)  # =>[b*60,15,2*hidden_size], [b*60,2,hidden_size]
        word_attn = self.word_attn(word_encoder_output).tanh()  # =>[b*60,15,hidden_size]
        word_attn_energy = self.word_ctx(word_attn)  # =>[b*60,15,1]
        word_attn_weights = F.softmax(word_attn_energy, dim=1).transpose(1, 2)  # =>[b*60,15,1]=>[b*60,1,15]
        word_att_level_output = torch.bmm(word_attn_weights, word_encoder_output)  # =>[b*60,1,2*hidden_size]

        sent_inputs = word_att_level_output.squeeze(1).view(-1, self.max_sents_num,
                                                            2 * self.hidden_size)  # =>[b*60,2*hidden_size]=>[b,60,2*hidden_size]
        self.bi_rnn2.flatten_parameters()
        sent_encoder_output, hidden2 = self.bi_rnn2(sent_inputs, hidden2)  # =>[b,60,2*hidden_size], [b,2,hidden_size]
        sent_attn = self.sent_attn(sent_encoder_output).tanh()  # =>[b,60,hidden_size]
        sent_attn_energy = self.sent_ctx(sent_attn)  # =>[b,60,1]
        sent_attn_weights = F.softmax(sent_attn_energy, dim=1).transpose(1, 2)  # =>[b,60,1]=>[b,1,60]
        sent_att_level_output = torch.bmm(sent_attn_weights, sent_encoder_output)  # =>[b,1,2*hidden_size]

        # logits = self.out(self.dropout(self.layernorm2(sent_att_level_output.squeeze(1))))  # =>[b,2*hidden_size]=>[b,num_classes]
        logits = self.out(self.dropout(sent_att_level_output.squeeze(1)))  # =>[b,2*hidden_size]=>[b,num_classes]
        return logits  # [b,num_classes]