# -*- coding: utf-8 -*-
# file: BERT_SPC.py
# author: songyouwei <youwei0314@gmail.com>
# Copyright (C) 2019. All Rights Reserved.
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from layers.dynamic_rnn import DynamicLSTM


class GraphConvolution(nn.Module):
    """
    Simple GCN layer, similar to https://arxiv.org/abs/1609.02907
    """
    def __init__(self, in_features, out_features, bias=True):
        super(GraphConvolution, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.weight = nn.Parameter(torch.FloatTensor(in_features, out_features))
        if bias:
            self.bias = nn.Parameter(torch.FloatTensor(out_features))
        else:
            self.register_parameter('bias', None)

    def forward(self, text, adj):


        hidden = torch.matmul(text, self.weight)  # hidden:torch.Size([16, 128, 600])
        denom = torch.sum(adj, dim=2, keepdim=True) + 1  # denom:torch.Size([16, 128, 1])

        # torch.matmul(adj, hidden):torch.Size([16, 128, 600])
        output = torch.matmul(adj, hidden) / denom  # output:torch.Size([16, 128, 600])


        if self.bias is not None:
            return output + self.bias
        else:
            return output

class GELU(nn.Module):
    def __init__(self):
        super(GELU, self).__init__()

    def forward(self, x):
        return 0.5*x*(1+F.tanh(np.sqrt(2/np.pi)*(x+0.044715*torch.pow(x,3))))


class BERT_GCN(nn.Module):
    def __init__(self, bert, opt):
        super(BERT_GCN, self).__init__()
        self.bert = bert
        self.bert_dropout = nn.Dropout(opt.dropout)
        self.text_lstm = DynamicLSTM(opt.bert_dim, 384, num_layers=1, batch_first=True, bidirectional=True)
        self.gcn1 = GraphConvolution(opt.bert_dim, opt.bert_dim)
        self.gcn2 = GraphConvolution(opt.bert_dim, opt.bert_dim)
        self.gcn3 = GraphConvolution(opt.bert_dim, opt.bert_dim)
        self.gcn4 = GraphConvolution(opt.bert_dim, opt.bert_dim)
        self.gcn5 = GraphConvolution(opt.bert_dim, opt.bert_dim)
        self.gcn6 = GraphConvolution(opt.bert_dim, opt.bert_dim)
        # self.gcn1 = GraphConvolution(2 * opt.hidden_dim, 2 * opt.hidden_dim)
        # self.gcn2 = GraphConvolution(2 * opt.hidden_dim, 2 * opt.hidden_dim)
        # self.gcn3 = GraphConvolution(2 * opt.hidden_dim, 2 * opt.hidden_dim)
        # self.gcn4 = GraphConvolution(2 * opt.hidden_dim, 2 * opt.hidden_dim)
        # self.gcn5 = GraphConvolution(2 * opt.hidden_dim, 2 * opt.hidden_dim)
        # self.gcn6 = GraphConvolution(2 * opt.hidden_dim, 2 * opt.hidden_dim)

        self.dense1 = nn.Linear(2 * opt.hidden_dim, 128)
        self.dense2 = nn.Linear(128, opt.polarities_dim)
        self.gelu = GELU()

        # FUSION Layer
        self.g = nn.Sequential(
            nn.Linear(1536, 768),
            nn.Sigmoid()
        )

        self.stance_classifier = nn.Sequential(
            nn.Linear(768, opt.hidden_dim),
            nn.ReLU(),
            nn.Dropout(opt.dropout),
            nn.Linear(opt.hidden_dim, 3)
        )

    def forward(self, inputs):
        text_target_bert_indices, attention_mask, bert_segments_ids, in_adj, text_bert_indices, attention_mask_raw, target_bert_indices, attention_mask_raw_target = inputs
        text_len = torch.sum(text_target_bert_indices != 0, dim=-1)
        word_output, f_obj = self.bert(text_bert_indices, attention_mask=attention_mask_raw)
        _, f_subj = self.bert(target_bert_indices, attention_mask=attention_mask_raw_target)

        word_output = self.bert_dropout(word_output)
        text_out, (_, _) = self.text_lstm(word_output, text_len)  # text_out:torch.Size([16, 128, 600])

        x = F.relu(self.gcn1(text_out, in_adj))  # in_adj层输出维度:torch.Size([16, 128, 128])
        x = F.relu(self.gcn2(x, in_adj))  # cross_adj层输出维度:torch.Size([16, 128 128])
        x = F.relu(self.gcn3(x, in_adj))
        x = F.relu(self.gcn4(x, in_adj))
        x = F.relu(self.gcn5(x, in_adj))
        x = F.relu(self.gcn6(x, in_adj))

        alpha_mat = torch.matmul(x, text_out.transpose(1, 2))  # alpha_mat层输出维度:torch.Size([64, 128, 128])
        alpha = F.softmax(alpha_mat.sum(1, keepdim=True), dim=2)  # alpha层输出维度:torch.Size([64, 1, 128])
        x = torch.matmul(alpha, text_out).squeeze(1)  # batch_size x 2*hidden_dim  x层输出维度:torch.Size([64, 768])

        f_obj_subj = torch.cat((x, f_subj), dim=1)
        g = self.g(f_obj_subj)
        f_dual = (g * f_subj) + ((1 - g) * x)
        stance_prediction = self.stance_classifier(f_dual)


        return stance_prediction


