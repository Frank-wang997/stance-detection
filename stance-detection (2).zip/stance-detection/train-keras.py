#! -*- coding:utf-8 -*-
# 情感分析例子
from pathlib import Path
import os, json
import numpy as np
from bert4keras.backend import keras, set_gelu
from bert4keras.tokenizers import Tokenizer
from bert4keras.models import build_transformer_model
from bert4keras.optimizers import Adam
from bert4keras.snippets import sequence_padding, DataGenerator
from bert4keras.snippets import open
from keras.layers import Lambda, Dense
from sklearn import metrics
import jieba
import random
import tensorflow as tf

jieba.initialize()
os.environ["CUDA_VISIBLE_DEVICES"] = "2"

modelPath = os.path.dirname(os.path.realpath(__file__))
num_classes = 3
maxlen = 128
batch_size = 64

# bert配置
config_path = modelPath + '/word-embedding/pretrain/wobert-zh/bert_config.json'
checkpoint_path = modelPath + '/word-embedding/pretrain/wobert-zh/bert_model.ckpt'
dict_path = modelPath + '/word-embedding/pretrain/wobert-zh/vocab.txt'


def seed_tensorflow(seed=42):
    os.environ['PYTHONHASHSEED'] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    tf.random.set_random_seed(seed)
    os.environ['TF_DETERMINISTIC_OPS'] = '1'


seed_tensorflow(42)


def load_data(filename):
    D = []
    with open(filename, 'r', encoding='utf8') as train:
        for line in train:
            if len(line.split("\t")) != 4: continue
            line = line.replace('\n', '').replace('\r', '')
            if line.split("\t")[3] == "FAVOR":
                stance = 2
            elif line.split("\t")[3] == "AGAINST":
                stance = 0
            else:
                stance = 1
            D.append((line.split("\t")[2][:128], stance))

    return D


# 加载数据集
train_data = load_data(modelPath + '/datasets/weibo-train')
valid_data = load_data(modelPath + '/datasets/weibo-test')
test_data = load_data(modelPath + '/datasets/weibo-test')

random.shuffle(train_data)
train_data = train_data[:512]

# 建立分词器
token_dict, keep_tokens, compound_tokens = json.load(
    open('tokenizer_config.json')
)
tokenizer = Tokenizer(
    token_dict,
    do_lower_case=True,
    pre_tokenize=lambda s: jieba.cut(s, HMM=False)
)


class data_generator(DataGenerator):
    """数据生成器
    """

    def __iter__(self, random=False):
        batch_token_ids, batch_segment_ids, batch_labels = [], [], []
        for is_end, (text, label) in self.sample(random):
            token_ids, segment_ids = tokenizer.encode(text, maxlen=maxlen)
            batch_token_ids.append(token_ids)
            batch_segment_ids.append(segment_ids)
            batch_labels.append([label])
            if len(batch_token_ids) == self.batch_size or is_end:
                batch_token_ids = sequence_padding(batch_token_ids)
                batch_segment_ids = sequence_padding(batch_segment_ids)
                batch_labels = sequence_padding(batch_labels)
                yield [batch_token_ids, batch_segment_ids], batch_labels
                batch_token_ids, batch_segment_ids, batch_labels = [], [], []


bert = build_transformer_model(
    config_path,
    checkpoint_path,
    keep_tokens=keep_tokens,  # 只保留keep_tokens中的字，精简原字表
    compound_tokens=compound_tokens,  # 增加词，用字平均来初始化
    return_keras_model=False,
)

output = bert.model.output
output = Lambda(lambda x: x[:, 0], name='CLS-token')(output)
output = Dense(
    units=num_classes,
    activation='softmax',
    kernel_initializer=bert.initializer
)(output)

model = keras.models.Model(bert.model.input, output)
model.summary()

model.compile(
    loss='sparse_categorical_crossentropy',
    optimizer=Adam(1e-5),  # 用足够小的学习率
    metrics=['accuracy'],
)

# 转换数据集
train_generator = data_generator(train_data, batch_size)
valid_generator = data_generator(valid_data, batch_size)
test_generator = data_generator(test_data, batch_size)


def evaluate(data, is_test=False):
    total, right = 0., 0.
    y_true, y_pred = [], []
    for x_true, y_true_item in data:
        y_pred_item = model.predict(x_true).argmax(axis=1)
        y_true_item = y_true_item[:, 0]
        total += len(y_true_item)
        right += (y_true_item == y_pred_item).sum()
        y_true = y_true + y_true_item.tolist()
        y_pred = y_pred + y_pred_item.tolist()

    f1_mac = metrics.f1_score(y_true, y_pred, labels=[0, 2], average='macro')
    f1_mic = metrics.f1_score(y_true, y_pred, labels=[0, 2], average='micro')

    acc_sk = metrics.accuracy_score(y_true, y_pred)
    precision = metrics.precision_score(y_true, y_pred, labels=[0, 2], average='macro')
    recall = metrics.recall_score(y_true, y_pred, labels=[0, 2], average='macro')
    class_result = metrics.classification_report(y_true, y_pred, target_names=['反对', '中立', '支持'], digits=4)
    print(class_result)
    print(
        '>> test_acc: {:.4f}, test_precision:{:.4f}, test_recall:{:.4f}, test_f1_mac: {:.4f}, test_f1_mic: {:.4f}'.format(
            acc_sk, precision,
            recall, f1_mac, f1_mic))
    if is_test:
        eval_each_target(y_true, y_pred)

    return f1_mac


def eval_each_target(y_trues, y_preds):
    target_list = ['CJ', 'SE', 'FK', 'ET', 'SZ']
    count = 0
    for i in range(0, len(y_trues) - 200, 200):
        f1_mac = metrics.f1_score(y_trues[i:i + 200], y_preds[i:i + 200], labels=[0, 2], average='macro')
        print('{}:'.format(target_list[count]))
        print(u'val_f1: %.4f\n' % (f1_mac))
        count = count + 1


class Evaluator(keras.callbacks.Callback):
    def __init__(self):
        self.best_val_acc = 0.
        self.best_val_f1 = 0.

    def on_epoch_end(self, epoch, logs=None):
        val_f1 = evaluate(valid_generator)
        if val_f1 > self.best_val_f1:
            self.best_val_f1 = val_f1
            model.save_weights(modelPath + '/output/keras/best_model_stance.weights')
        # test_f1 = evaluate(test_generator)
        print(u'val_f1: %.5f, best_val_f1: %.5f\n' % (val_f1, self.best_val_f1))


if __name__ == '__main__':

    evaluator = Evaluator()

    model.fit_generator(
        train_generator.forfit(),
        steps_per_epoch=len(train_generator),
        epochs=10,
        callbacks=[evaluator]
    )

    model.load_weights(modelPath + '/output/keras/best_model_stance.weights')
    print(u'final test acc: %04f\n' % (evaluate(test_generator, is_test=True)))

else:

    model.load_weights(modelPath + '/output/keras/best_model_stance.weights')
