#! -*- coding: utf-8 -*-

__version__ = '0.9.2'


